# Catalog Agent — Enriched + Recursive

Gerador de catálogo Backstage com GitHub REST API + LangChain + Amazon Bedrock.

## Enriquecimentos

- Languages API: bytes e percentual por linguagem.
- CODEOWNERS: owners, global owners e erros de sintaxe.
- Teams do repositório e permissões.
- Contributors e quantidade de contribuições.
- Topics, licença, visibilidade, branch default, datas, homepage e status archived/fork.

## Recursividade / monorepo

A árvore Git é obtida recursivamente e o scanner identifica raízes de módulos usando manifests como `pom.xml`, `package.json`, `pyproject.toml`, `go.mod`, `*.csproj`, `Chart.yaml`, Terraform, Docker e outros. Para cada módulo ele seleciona recursivamente manifests, configurações e arquivos fonte representativos. A IA recebe evidências separadas por módulo e gera uma análise agregada do repo.

## Saída

`catalog-output/<nomedorepo>_cataloginfo.yaml`

O JSON inclui o descriptor Backstage e também:

- `x-ai-analysis.modules`
- `x-ai-analysis.evidence`
- `x-github-enrichment`


## Formato de saída

A saída é YAML, pronta para uso/transformação no ecossistema Backstage:

```text
catalog-output/
└── <nomedorepo>_cataloginfo.yaml
```

O arquivo é serializado com `yaml.safe_dump`, preservando ordem das chaves e Unicode.

## Instalação

```bash
python -m venv .venv
pip install -r requirements.txt
```

Windows:

```powershell
.venv\Scripts\Activate.ps1
Copy-Item .env.example .env
```

Linux/macOS:

```bash
source .venv/bin/activate
cp .env.example .env
```

## Execução

Um repo:

```bash
python catalog_agent.py --repo nome-do-repo
```

Três repos:

```bash
python catalog_agent.py --limit 3
```

Todos:

```bash
python catalog_agent.py
```

Reprocessar:

```bash
python catalog_agent.py --overwrite
```

## Ownership

Com `USE_CODEOWNERS_OWNER=true`, um owner global do CODEOWNERS pode alimentar `spec.owner`. Um `@org/time` vira `group:default/time`; um `@usuario` vira `user:default/usuario`. Sem owner global, usa `BACKSTAGE_OWNER`. Times com acesso ao repo são registrados como metadado, mas não são automaticamente tratados como owners.

## Permissões GitHub

Para repos privados, o token precisa ler metadata e contents. O endpoint de teams pode exigir `Administration: read`; se não estiver disponível, o script mostra warning e continua com os outros enriquecimentos.

## Controle de custo/contexto

Ajuste no `.env`:

- `MAX_MODULES`
- `MAX_MANIFESTS_PER_MODULE`
- `MAX_CONFIGS_PER_MODULE`
- `MAX_SOURCES_PER_MODULE`
- `MAX_FILE_SIZE`
- `MAX_FILE_CHARS`
- `MAX_TREE_LINES`
