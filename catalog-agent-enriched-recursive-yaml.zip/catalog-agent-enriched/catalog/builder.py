import json
import re
import unicodedata

def normalize_tag(value: str):
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii").lower()
    value = re.sub(r"[^a-z0-9+#-]+", "-", value)
    return value.strip("-")[:63]

def annotation_csv(values):
    return ",".join(str(v) for v in values if v is not None and str(v) != "")

def owner_from_codeowners(global_codeowners: list[str], fallback: str):
    if not global_codeowners:
        return fallback
    owner = global_codeowners[0].lstrip("@")
    if "/" in owner:
        _, team = owner.split("/", 1)
        return f"group:default/{normalize_tag(team)}"
    return f"user:default/{normalize_tag(owner)}"

def build_catalog_info(repo, analysis, enrichment, default_owner: str, annotation_prefix: str, use_codeowners_owner: bool = True):
    repo_name = repo["name"]
    github_languages = list(enrichment.languages_percent.keys())
    technologies = github_languages + analysis.frameworks + analysis.runtimes + analysis.databases + analysis.messaging + analysis.cloud_services + analysis.infrastructure + analysis.ci_cd + analysis.observability + analysis.architecture + enrichment.topics
    tags, seen = [], set()
    for tech in technologies:
        tag = normalize_tag(tech)
        if tag and tag not in seen:
            seen.add(tag); tags.append(tag)
    annotations = {
        "github.com/project-slug": f"{repo.get('owner', {}).get('login', '')}/{repo_name}",
        "backstage.io/source-location": f"url:{repo['html_url']}/",
        f"{annotation_prefix}/languages": annotation_csv(github_languages),
        f"{annotation_prefix}/languages-percent": json.dumps(enrichment.languages_percent, ensure_ascii=False, separators=(",", ":")),
        f"{annotation_prefix}/frameworks": annotation_csv(analysis.frameworks),
        f"{annotation_prefix}/runtimes": annotation_csv(analysis.runtimes),
        f"{annotation_prefix}/databases": annotation_csv(analysis.databases),
        f"{annotation_prefix}/messaging": annotation_csv(analysis.messaging),
        f"{annotation_prefix}/cloud": annotation_csv(analysis.cloud_services),
        f"{annotation_prefix}/infrastructure": annotation_csv(analysis.infrastructure),
        f"{annotation_prefix}/ci-cd": annotation_csv(analysis.ci_cd),
        f"{annotation_prefix}/observability": annotation_csv(analysis.observability),
        f"{annotation_prefix}/architecture": annotation_csv(analysis.architecture),
        f"{annotation_prefix}/topics": annotation_csv(enrichment.topics),
        f"{annotation_prefix}/codeowners": annotation_csv(enrichment.codeowners),
        f"{annotation_prefix}/global-codeowners": annotation_csv(enrichment.global_codeowners),
        f"{annotation_prefix}/codeowners-file": enrichment.codeowners_path or "",
        f"{annotation_prefix}/teams": annotation_csv(enrichment.teams),
        f"{annotation_prefix}/team-permissions": json.dumps(enrichment.team_permissions, ensure_ascii=False, separators=(",", ":")),
        f"{annotation_prefix}/top-contributors": annotation_csv(enrichment.contributors[:15]),
        f"{annotation_prefix}/license": enrichment.license_spdx or "",
        f"{annotation_prefix}/visibility": enrichment.visibility or "",
        f"{annotation_prefix}/default-branch": enrichment.default_branch or "",
        f"{annotation_prefix}/archived": str(enrichment.archived).lower(),
        f"{annotation_prefix}/fork": str(enrichment.fork).lower(),
        f"{annotation_prefix}/last-push": enrichment.pushed_at or "",
        f"{annotation_prefix}/ai-confidence": str(analysis.confidence),
        f"{annotation_prefix}/module-count": str(len(analysis.modules)),
        f"{annotation_prefix}/generated-by": "langchain-bedrock-github-enriched",
    }
    if enrichment.codeowners_errors:
        annotations[f"{annotation_prefix}/codeowners-errors"] = annotation_csv(enrichment.codeowners_errors[:10])
    annotations = {k: v for k, v in annotations.items() if v not in ("", None, "{}", "[]")}
    links = [{"url": repo["html_url"], "title": "GitHub Repository", "icon": "github"}]
    if enrichment.homepage:
        links.append({"url": enrichment.homepage, "title": "Homepage"})
    owner = owner_from_codeowners(enrichment.global_codeowners, default_owner) if use_codeowners_owner else default_owner
    return {
        "apiVersion": "backstage.io/v1alpha1",
        "kind": "Component",
        "metadata": {"name": normalize_tag(repo_name), "description": analysis.summary, "annotations": annotations, "tags": tags, "links": links},
        "spec": {"type": analysis.component_type, "lifecycle": analysis.lifecycle, "owner": owner},
        "x-ai-analysis": {"modules": [m.model_dump() for m in analysis.modules], "evidence": analysis.evidence},
        "x-github-enrichment": enrichment.model_dump(),
    }
