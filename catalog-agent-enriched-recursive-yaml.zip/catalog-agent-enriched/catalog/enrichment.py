from .models import RepoEnrichment
from .scanner import find_codeowners_entry, parse_codeowners


def _percentages(languages: dict[str, int]) -> dict[str, float]:
    total = sum(languages.values())
    if total <= 0:
        return {}
    return {language: round((size / total) * 100, 2) for language, size in sorted(languages.items(), key=lambda item: item[1], reverse=True)}


def enrich_repository(client, repo: dict, tree: list[dict]) -> RepoEnrichment:
    repo_name = repo["name"]
    languages = client.get_languages(repo_name)
    topics, teams, contributors, codeowners_errors = [], [], [], []

    try:
        topics = client.get_topics(repo_name)
    except Exception as exc:
        print(f"    ⚠️ topics indisponível: {exc}")

    try:
        teams = client.get_teams(repo_name) or []
    except Exception as exc:
        print(f"    ⚠️ teams indisponível (Administration:read pode ser necessária): {exc}")

    try:
        contributors = client.get_contributors(repo_name) or []
    except Exception as exc:
        print(f"    ⚠️ contributors indisponível: {exc}")

    try:
        codeowners_errors = client.get_codeowners_errors(repo_name, repo.get("default_branch", "main"))
    except Exception as exc:
        print(f"    ⚠️ CODEOWNERS errors indisponível: {exc}")

    codeowners_path = None
    codeowners = []
    global_codeowners = []
    entry = find_codeowners_entry(tree)
    if entry:
        codeowners_path = entry["path"]
        content = client.get_blob(repo_name, entry["sha"])
        codeowners, global_codeowners = parse_codeowners(content)

    normalized_errors = []
    for error in codeowners_errors or []:
        if isinstance(error, dict):
            normalized_errors.append(f"line={error.get('line')},column={error.get('column')}: {error.get('message') or error.get('kind') or str(error)}")
        else:
            normalized_errors.append(str(error))

    team_names, team_permissions = [], {}
    for team in teams:
        slug = team.get("slug") or team.get("name")
        if not slug:
            continue
        team_names.append(slug)
        if team.get("permission"):
            team_permissions[slug] = team["permission"]

    contributor_names, contributor_commits = [], {}
    for contributor in contributors:
        login = contributor.get("login") or contributor.get("name")
        if not login:
            continue
        contributor_names.append(login)
        if contributor.get("contributions") is not None:
            contributor_commits[login] = contributor["contributions"]

    license_obj = repo.get("license") or {}

    return RepoEnrichment(
        languages_bytes=languages,
        languages_percent=_percentages(languages),
        topics=topics,
        codeowners_path=codeowners_path,
        codeowners=codeowners,
        global_codeowners=global_codeowners,
        codeowners_errors=normalized_errors,
        teams=team_names,
        team_permissions=team_permissions,
        contributors=contributor_names[:50],
        contributor_commits=dict(list(contributor_commits.items())[:50]),
        license_spdx=license_obj.get("spdx_id"),
        visibility=repo.get("visibility"),
        default_branch=repo.get("default_branch"),
        archived=bool(repo.get("archived")),
        fork=bool(repo.get("fork")),
        homepage=repo.get("homepage"),
        created_at=repo.get("created_at"),
        updated_at=repo.get("updated_at"),
        pushed_at=repo.get("pushed_at"),
        size_kb=repo.get("size"),
        open_issues_count=repo.get("open_issues_count"),
    )
