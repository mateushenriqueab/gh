import base64
import requests
from urllib.parse import quote


class GitHubClient:
    def __init__(self, token: str, org: str, api_version: str = "2026-03-10"):
        self.token = token
        self.org = org
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": api_version,
            "User-Agent": "catalog-ai-agent",
        })

    def get(self, url: str, *, allow_statuses: set[int] | None = None, **kwargs):
        response = self.session.get(url, timeout=60, **kwargs)
        if allow_statuses and response.status_code in allow_statuses:
            return None
        response.raise_for_status()
        if response.status_code == 204:
            return None
        return response.json()

    def paginated(self, url: str, params: dict | None = None, max_pages: int = 20):
        params = dict(params or {})
        params["per_page"] = 100
        items = []
        for page in range(1, max_pages + 1):
            params["page"] = page
            data = self.get(url, params=params)
            if not data:
                break
            if isinstance(data, dict):
                for key in ("items", "names"):
                    if key in data and isinstance(data[key], list):
                        data = data[key]
                        break
            if not isinstance(data, list):
                return data
            items.extend(data)
            if len(data) < 100:
                break
        return items

    def list_org_repositories(self):
        return self.paginated(
            f"https://api.github.com/orgs/{self.org}/repos",
            params={"type": "all", "sort": "full_name", "direction": "asc"},
        )

    def get_tree(self, repo: str, default_branch: str):
        branch = quote(default_branch, safe="")
        return self.get(
            f"https://api.github.com/repos/{self.org}/{repo}/git/trees/{branch}",
            params={"recursive": "1"},
        ) or {"tree": [], "truncated": False}

    def get_blob(self, repo: str, sha: str):
        blob = self.get(f"https://api.github.com/repos/{self.org}/{repo}/git/blobs/{sha}")
        if not blob or blob.get("encoding") != "base64":
            return ""
        try:
            return base64.b64decode(blob["content"]).decode("utf-8", errors="replace")
        except Exception:
            return ""

    def get_languages(self, repo: str):
        return self.get(f"https://api.github.com/repos/{self.org}/{repo}/languages") or {}

    def get_topics(self, repo: str):
        data = self.get(
            f"https://api.github.com/repos/{self.org}/{repo}/topics",
            allow_statuses={403, 404},
        )
        return (data or {}).get("names", [])

    def get_teams(self, repo: str):
        return self.paginated(f"https://api.github.com/repos/{self.org}/{repo}/teams")

    def get_contributors(self, repo: str):
        return self.paginated(
            f"https://api.github.com/repos/{self.org}/{repo}/contributors",
            params={"anon": "true"},
            max_pages=5,
        )

    def get_codeowners_errors(self, repo: str, ref: str):
        data = self.get(
            f"https://api.github.com/repos/{self.org}/{repo}/codeowners/errors",
            params={"ref": ref},
            allow_statuses={403, 404},
        )
        return (data or {}).get("errors", [])
