from typing import Literal
from pydantic import BaseModel, Field


class ModuleAnalysis(BaseModel):
    path: str = Field(description="Module/root path inside the repository")
    kind: str = Field(description="Short module kind such as backend, frontend, library, infra or unknown")
    frameworks: list[str] = Field(default_factory=list)
    runtimes: list[str] = Field(default_factory=list)
    databases: list[str] = Field(default_factory=list)
    messaging: list[str] = Field(default_factory=list)
    cloud_services: list[str] = Field(default_factory=list)
    infrastructure: list[str] = Field(default_factory=list)
    ci_cd: list[str] = Field(default_factory=list)
    observability: list[str] = Field(default_factory=list)
    architecture: list[str] = Field(default_factory=list)
    evidence: list[str] = Field(default_factory=list)


class TechAnalysis(BaseModel):
    summary: str = Field(description="Short technical description of the repository")
    component_type: Literal["service", "website", "library", "tool", "infrastructure", "other"]
    lifecycle: Literal["production", "development", "experimental", "deprecated"] = "production"
    frameworks: list[str] = Field(default_factory=list)
    runtimes: list[str] = Field(default_factory=list)
    databases: list[str] = Field(default_factory=list)
    messaging: list[str] = Field(default_factory=list)
    cloud_services: list[str] = Field(default_factory=list)
    infrastructure: list[str] = Field(default_factory=list)
    ci_cd: list[str] = Field(default_factory=list)
    observability: list[str] = Field(default_factory=list)
    architecture: list[str] = Field(default_factory=list)
    modules: list[ModuleAnalysis] = Field(default_factory=list)
    confidence: float = Field(ge=0, le=1)
    evidence: list[str] = Field(default_factory=list)


class RepoEnrichment(BaseModel):
    languages_bytes: dict[str, int] = Field(default_factory=dict)
    languages_percent: dict[str, float] = Field(default_factory=dict)
    topics: list[str] = Field(default_factory=list)
    codeowners_path: str | None = None
    codeowners: list[str] = Field(default_factory=list)
    global_codeowners: list[str] = Field(default_factory=list)
    codeowners_errors: list[str] = Field(default_factory=list)
    teams: list[str] = Field(default_factory=list)
    team_permissions: dict[str, str] = Field(default_factory=dict)
    contributors: list[str] = Field(default_factory=list)
    contributor_commits: dict[str, int] = Field(default_factory=dict)
    license_spdx: str | None = None
    visibility: str | None = None
    default_branch: str | None = None
    archived: bool = False
    fork: bool = False
    homepage: str | None = None
    created_at: str | None = None
    updated_at: str | None = None
    pushed_at: str | None = None
    size_kb: int | None = None
    open_issues_count: int | None = None
