from dataclasses import dataclass, field
from pathlib import PurePosixPath
import re

IGNORED_DIRS = {".git", ".idea", ".vscode", "node_modules", "vendor", "dist", "build", "target", ".next", ".nuxt", "coverage", ".terraform", "__pycache__", ".venv", "venv"}
MANIFEST_NAMES = {"pom.xml", "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts", "package.json", "pyproject.toml", "requirements.txt", "Pipfile", "setup.py", "go.mod", "Cargo.toml", "Gemfile", "composer.json", "global.json", "Dockerfile", "docker-compose.yml", "docker-compose.yaml", "compose.yml", "compose.yaml", "Chart.yaml", "serverless.yml", "serverless.yaml", "template.yaml", "template.yml", "main.tf", "providers.tf", "versions.tf"}
SOURCE_EXTENSIONS = {".java", ".kt", ".kts", ".groovy", ".ts", ".tsx", ".js", ".jsx", ".vue", ".py", ".go", ".rs", ".cs", ".rb", ".php", ".scala", ".swift", ".c", ".cc", ".cpp", ".h", ".hpp"}
CONFIG_EXTENSIONS = {".yml", ".yaml", ".json", ".toml", ".properties", ".xml", ".tf", ".hcl"}
IMPORTANT_CONFIG_NAMES = {"application.yml", "application.yaml", "application.properties", "bootstrap.yml", "bootstrap.yaml", "appsettings.json", "tsconfig.json", "vite.config.ts", "vite.config.js", "nuxt.config.ts", "next.config.js", "next.config.mjs", "angular.json", "workspace.json", "nx.json", "turbo.json", "lerna.json", "Dockerfile"}
SOURCE_NAME_HINTS = ("main", "app", "application", "server", "bootstrap", "controller", "handler", "route", "router", "service", "repository", "consumer", "producer", "listener", "config", "module")

@dataclass
class ScanFile:
    path: str
    sha: str
    size: int
    category: str
    module_root: str = "."

@dataclass
class ModuleScan:
    root: str
    manifests: list[ScanFile] = field(default_factory=list)
    configs: list[ScanFile] = field(default_factory=list)
    sources: list[ScanFile] = field(default_factory=list)

def _ignored(path: str) -> bool:
    return any(part in IGNORED_DIRS for part in PurePosixPath(path).parts)

def _basename(path: str) -> str:
    return PurePosixPath(path).name

def _dirname(path: str) -> str:
    parent = str(PurePosixPath(path).parent)
    return "." if parent == "." else parent

def _is_manifest(path: str) -> bool:
    name = _basename(path)
    lower = name.lower()
    return name in MANIFEST_NAMES or lower in {x.lower() for x in MANIFEST_NAMES} or lower.endswith(".csproj") or lower.endswith(".sln")

def discover_module_roots(tree: list[dict], max_modules: int = 50) -> list[str]:
    roots = {"."}
    for entry in tree:
        if entry.get("type") != "blob":
            continue
        path = entry["path"]
        if _ignored(path):
            continue
        if _is_manifest(path):
            roots.add(_dirname(path))
    return sorted(roots, key=lambda p: (p.count("/"), p))[:max_modules]

def _belongs_to_module(path: str, module_root: str, module_roots: set[str]) -> bool:
    if module_root == ".":
        return not any(other != "." and (path == other or path.startswith(other + "/")) for other in module_roots)
    if not (path == module_root or path.startswith(module_root + "/")):
        return False
    return not any(other != module_root and other.startswith(module_root + "/") and (path == other or path.startswith(other + "/")) for other in module_roots)

def _source_score(path: str) -> int:
    name = PurePosixPath(path).stem.lower()
    lower = path.lower()
    score = 0
    if "/src/" in f"/{lower}/" or lower.startswith("src/"):
        score += 30
    if any(hint in name for hint in SOURCE_NAME_HINTS):
        score += 50
    if "/test/" in f"/{lower}/" or "/tests/" in f"/{lower}/":
        score -= 25
    if "/generated/" in f"/{lower}/":
        score -= 50
    return score - path.count("/")

def _config_score(path: str) -> int:
    name = _basename(path)
    lower = path.lower()
    score = 0
    if name in IMPORTANT_CONFIG_NAMES:
        score += 80
    if ".github/workflows/" in lower:
        score += 60
    if any(part in lower for part in ("/k8s/", "/kubernetes/", "/helm/", "/terraform/", "/infra/", "/deploy/")):
        score += 50
    if name.lower() in {"readme.md", "codeowners"}:
        score += 30
    return score - path.count("/")

def scan_modules(tree: list[dict], max_modules: int = 50, max_manifests_per_module: int = 12, max_configs_per_module: int = 12, max_sources_per_module: int = 10, max_file_size: int = 150_000) -> list[ModuleScan]:
    roots = discover_module_roots(tree, max_modules=max_modules)
    root_set = set(roots)
    scans = {root: ModuleScan(root=root) for root in roots}
    for entry in tree:
        if entry.get("type") != "blob":
            continue
        path = entry["path"]
        size = entry.get("size") or 0
        if size > max_file_size or _ignored(path):
            continue
        candidates = [root for root in roots if _belongs_to_module(path, root, root_set)]
        if not candidates:
            continue
        owning_root = max(candidates, key=len)
        scan = scans[owning_root]
        suffix = PurePosixPath(path).suffix.lower()
        name = _basename(path)
        if _is_manifest(path):
            scan.manifests.append(ScanFile(path, entry["sha"], size, "manifest", owning_root))
        elif suffix in SOURCE_EXTENSIONS:
            scan.sources.append(ScanFile(path, entry["sha"], size, "source", owning_root))
        elif suffix in CONFIG_EXTENSIONS or name in IMPORTANT_CONFIG_NAMES or path.lower().startswith(".github/workflows/") or name.lower() in {"readme.md", "codeowners"}:
            scan.configs.append(ScanFile(path, entry["sha"], size, "config", owning_root))
    result = []
    for root in roots:
        scan = scans[root]
        scan.manifests = sorted(scan.manifests, key=lambda f: (f.path.count("/"), f.path))[:max_manifests_per_module]
        scan.configs = sorted(scan.configs, key=lambda f: _config_score(f.path), reverse=True)[:max_configs_per_module]
        scan.sources = sorted(scan.sources, key=lambda f: _source_score(f.path), reverse=True)[:max_sources_per_module]
        if root == "." and not (scan.manifests or scan.configs or scan.sources) and len(roots) > 1:
            continue
        result.append(scan)
    return result

def render_tree(tree: list[dict], max_lines: int = 4000) -> str:
    lines = []
    for entry in tree:
        path = entry["path"]
        if _ignored(path):
            continue
        lines.append(f"{entry.get('type', '?'):4} {path}")
        if len(lines) >= max_lines:
            lines.append("... TREE TRUNCATED ...")
            break
    return "\n".join(lines)

def find_codeowners_entry(tree: list[dict]):
    by_path = {entry["path"]: entry for entry in tree if entry.get("type") == "blob"}
    for candidate in (".github/CODEOWNERS", "CODEOWNERS", "docs/CODEOWNERS"):
        if candidate in by_path:
            return by_path[candidate]
    return None

def parse_codeowners(content: str):
    owners = []
    global_owners = []
    for raw_line in content.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        parts = re.split(r"\s+", line)
        if len(parts) < 2:
            continue
        pattern = parts[0]
        row_owners = [x for x in parts[1:] if x.startswith("@") ]
        for owner in row_owners:
            if owner not in owners:
                owners.append(owner)
        if pattern in {"*", "**", "**/*", "/*", "/**"}:
            for owner in row_owners:
                if owner not in global_owners:
                    global_owners.append(owner)
    return owners, global_owners
