import argparse
import os
import yaml
from pathlib import Path
from dotenv import load_dotenv
from catalog.agent import CatalogAnalyzer
from catalog.builder import build_catalog_info
from catalog.enrichment import enrich_repository
from catalog.github_client import GitHubClient
from catalog.scanner import scan_modules

load_dotenv()

def env_bool(name: str, default: bool):
    value = os.getenv(name)
    return default if value is None else value.strip().lower() in {"1", "true", "yes", "y", "on"}

GITHUB_TOKEN = os.environ["GITHUB_TOKEN"]
GITHUB_ORG = os.environ["GITHUB_ORG"]
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
BEDROCK_MODEL_ID = os.environ["BEDROCK_MODEL_ID"]
BACKSTAGE_OWNER = os.getenv("BACKSTAGE_OWNER", "group:default/platform")
ANNOTATION_PREFIX = os.getenv("ANNOTATION_PREFIX", "internal.ai")
OUTPUT_DIR = Path(os.getenv("OUTPUT_DIR", "./catalog-output"))
USE_CODEOWNERS_OWNER = env_bool("USE_CODEOWNERS_OWNER", True)
MAX_MODULES = int(os.getenv("MAX_MODULES", "50"))
MAX_MANIFESTS_PER_MODULE = int(os.getenv("MAX_MANIFESTS_PER_MODULE", "12"))
MAX_CONFIGS_PER_MODULE = int(os.getenv("MAX_CONFIGS_PER_MODULE", "12"))
MAX_SOURCES_PER_MODULE = int(os.getenv("MAX_SOURCES_PER_MODULE", "10"))
MAX_FILE_SIZE = int(os.getenv("MAX_FILE_SIZE", "150000"))
MAX_FILE_CHARS = int(os.getenv("MAX_FILE_CHARS", "14000"))
MAX_TREE_LINES = int(os.getenv("MAX_TREE_LINES", "4000"))

client = GitHubClient(GITHUB_TOKEN, GITHUB_ORG)
analyzer = CatalogAnalyzer(BEDROCK_MODEL_ID, AWS_REGION, MAX_FILE_CHARS, MAX_TREE_LINES)

def process_repository(repo: dict, overwrite: bool = False):
    repo_name = repo["name"]
    output_file = OUTPUT_DIR / f"{repo_name}_cataloginfo.yaml"
    if output_file.exists() and not overwrite:
        print(f"⏭️  {repo_name}: já existe, ignorando")
        return "skipped"

    print("\n" + "=" * 80)
    print(f"📦 {repo_name}")
    print("=" * 80)
    default_branch = repo.get("default_branch", "main")

    print("  🌳 lendo árvore recursiva...")
    tree_result = client.get_tree(repo_name, default_branch)
    tree = tree_result.get("tree", [])
    print(f"  📁 {len(tree)} entradas encontradas")
    if tree_result.get("truncated"):
        print("  ⚠️ GitHub marcou a árvore como truncated=true")

    print("  🧩 descobrindo módulos/subprojetos recursivamente...")
    modules = scan_modules(
        tree,
        max_modules=MAX_MODULES,
        max_manifests_per_module=MAX_MANIFESTS_PER_MODULE,
        max_configs_per_module=MAX_CONFIGS_PER_MODULE,
        max_sources_per_module=MAX_SOURCES_PER_MODULE,
        max_file_size=MAX_FILE_SIZE,
    )
    for module in modules:
        print(f"      ↳ {module.root}: {len(module.manifests)} manifests, {len(module.configs)} configs, {len(module.sources)} fontes")

    print("  🔎 enriquecendo com APIs do GitHub...")
    enrichment = enrich_repository(client, repo, tree)
    print("      languages:", ", ".join(f"{k}={v}%" for k, v in enrichment.languages_percent.items()) or "n/a")
    print("      CODEOWNERS:", ", ".join(enrichment.codeowners) or "n/a")
    print("      teams:", ", ".join(enrichment.teams) or "n/a")

    print("  🤖 lendo manifests/config/fontes por módulo...")
    context = analyzer.build_context(client, repo, tree, modules, enrichment)
    print("  🧠 analisando stack/arquitetura...")
    analysis = analyzer.analyze(context)

    catalog = build_catalog_info(repo, analysis, enrichment, BACKSTAGE_OWNER, ANNOTATION_PREFIX, USE_CODEOWNERS_OWNER)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    with output_file.open("w", encoding="utf-8") as f:
        json.dump(catalog, f, indent=2, ensure_ascii=False)
    print(f"  ✅ {output_file}")
    return "processed"

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--limit", type=int)
    parser.add_argument("--repo", type=str)
    args = parser.parse_args()

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    print("\n🤖 AI SOFTWARE CATALOG GENERATOR — ENRICHED + RECURSIVE")
    print(f"Organization : {GITHUB_ORG}")
    print(f"Region       : {AWS_REGION}")
    print(f"Model        : {BEDROCK_MODEL_ID}")
    print(f"Output       : {OUTPUT_DIR}\n")

    repos = client.list_org_repositories()
    if args.repo:
        repos = [r for r in repos if r["name"].lower() == args.repo.lower()]
        if not repos:
            raise SystemExit(f"Repositório '{args.repo}' não encontrado em {GITHUB_ORG}")
    if args.limit:
        repos = repos[:args.limit]

    counters = {"processed": 0, "skipped": 0, "failed": 0}
    for index, repo in enumerate(repos, start=1):
        print(f"\n[{index}/{len(repos)}]")
        try:
            counters[process_repository(repo, args.overwrite)] += 1
        except Exception as exc:
            counters["failed"] += 1
            print(f"❌ erro em {repo['name']}: {exc}")

    print("\n" + "=" * 80)
    print("FINALIZADO")
    print("=" * 80)
    print(f"✅ processados : {counters['processed']}")
    print(f"⏭️ ignorados   : {counters['skipped']}")
    print(f"❌ erros       : {counters['failed']}")

if __name__ == "__main__":
    main()
