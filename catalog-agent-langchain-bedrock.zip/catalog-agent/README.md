# Catalog Agent

Agente em Python + LangChain + AWS Bedrock que percorre os repositórios de uma organização GitHub,
analisa a estrutura e arquivos-chave de cada projeto e gera:

`catalog-output/<nomedorepo>_cataloginfo.json`

## Requisitos

- Python 3.11+
- Credenciais AWS válidas
- Acesso ao modelo configurado no Amazon Bedrock
- Token do GitHub com acesso de leitura aos repositórios da organização

## Instalação

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

Linux/macOS:

```bash
source .venv/bin/activate
```

Instale as dependências:

```bash
pip install -r requirements.txt
```

## Configuração

Copie:

```bash
cp .env.example .env
```

No Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

Preencha:

```env
GITHUB_ORG=minha-org
GITHUB_TOKEN=github_pat_xxxxx
AWS_REGION=us-east-1
BEDROCK_MODEL_ID=seu-model-id
```

As credenciais da AWS podem vir de:

- `aws configure`
- variáveis de ambiente
- IAM Role
- profile AWS
- workload identity/role em ambiente AWS

## Teste

Teste primeiro com 3 repositórios:

```bash
python catalog_agent.py --limit 3
```

Depois rode todos:

```bash
python catalog_agent.py
```

Para reprocessar arquivos já existentes:

```bash
python catalog_agent.py --overwrite
```

## Saída

```text
catalog-output/
├── repo-a_cataloginfo.json
├── repo-b_cataloginfo.json
└── repo-c_cataloginfo.json
```

A IA recebe:

- árvore do repositório
- manifests
- Dockerfile
- Terraform
- Helm/Kubernetes
- workflows
- README
- arquivos de build importantes

A classificação da stack é feita pelo modelo no Bedrock, usando resposta estruturada do LangChain/Pydantic.
