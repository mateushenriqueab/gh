# Reference notice

This project was written for this prototype and uses public Windows Credential Provider APIs.
The design and serialization approach follow Microsoft's public V2 Credential Provider sample/documentation and Keycloak's public OIDC Device Authorization endpoint documentation.
No Microsoft sample source tree is bundled verbatim in this package.
