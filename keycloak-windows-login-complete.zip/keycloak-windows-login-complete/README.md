# Keycloak Windows Login — Credential Provider + Bridge

Implementação completa para testar login do Windows usando uma identidade autenticada pelo Keycloak.

O projeto **não substitui o LSA/SAM do Windows**. O Keycloak prova a identidade online; o bridge cria/atualiza uma conta local gerenciada `kc_<hash>` com senha aleatória; o Credential Provider serializa essa credencial para o LogonUI; e o Windows realiza o logon local normalmente.

```text
Windows LogonUI
    │
    ▼
KeycloakCredentialProvider.dll (C++ x64)
    │  \\.\pipe\KeycloakWindowsBridge
    ▼
KeycloakWindowsBridge.exe (.NET 8 / LocalSystem)
    │
    ▼
Keycloak OIDC Device Authorization Grant
    │
    ├── usuário criado diretamente no Keycloak  ✅
    └── Identity Provider / Microsoft Entra      opcional
    │
    ▼
conta local kc_<hash(sub)> + senha randômica
    │
    ▼
KERB_INTERACTIVE_UNLOCK_LOGON / Negotiate
    │
    ▼
Windows SAM
```

## O que está incluído

```text
keycloak-windows-login-complete/
├── bridge/
│   ├── Models/
│   ├── Pipe/
│   ├── Services/
│   ├── KeycloakWindowsBridge.csproj
│   ├── Program.cs
│   ├── Worker.cs
│   └── appsettings.json
│
├── credential-provider/
│   ├── KeycloakCredentialProvider.sln
│   ├── KeycloakCredentialProvider.vcxproj
│   ├── CredentialProvider.def
│   ├── Dll.cpp/.h
│   ├── Provider.cpp/.h
│   ├── Credential.cpp/.h
│   ├── BridgeClient.cpp/.h
│   ├── Helpers.cpp/.h
│   ├── Fields.cpp/.h
│   └── Guid.cpp/.h
│
└── scripts/
    ├── build.ps1
    ├── install.ps1
    ├── uninstall.ps1
    └── status.ps1
```

## 1. Configure o client no Keycloak

Crie um client OIDC para o Windows:

```text
Client ID: windows-login
Client authentication: OFF
OAuth 2.0 Device Authorization Grant: ON
Direct Access Grants: OFF
```

Use os scopes:

```text
openid profile email
```

O fluxo funciona com um usuário criado em **Users** dentro do próprio realm do Keycloak. Microsoft Entra, LDAP ou AD não são necessários para o primeiro teste.

Exemplo:

```text
Realm: windows
User: mateus
Password: uma-senha-de-teste
```

## 2. Pré-requisitos para build

Na VM Windows x64:

- .NET 8 SDK
- Visual Studio 2022 Build Tools ou Visual Studio 2022
- workload **Desktop development with C++**
- MSVC v143 x64
- Windows 10/11 SDK

O script procura o MSBuild automaticamente usando `vswhere.exe`.

## 3. Build

Abra **PowerShell x64** e execute:

```powershell
cd C:\caminho\keycloak-windows-login-complete
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\build.ps1
```

Saídas:

```text
artifacts\bridge\KeycloakWindowsBridge.exe
artifacts\provider\KeycloakCredentialProvider.dll
```

O bridge é publicado como `win-x64` e `self-contained`, portanto a máquina de execução não precisa do runtime .NET separado depois do build.

## 4. Instalação

Abra PowerShell **como Administrador**.

Para Keycloak HTTPS:

```powershell
.\scripts\install.ps1 `
  -KeycloakBaseUrl "https://sso.exemplo.com" `
  -Realm "windows" `
  -ClientId "windows-login"
```

Para teste local, por exemplo Keycloak rodando no host do Hyper-V:

```powershell
.\scripts\install.ps1 `
  -KeycloakBaseUrl "http://172.24.224.1:8080" `
  -Realm "windows" `
  -ClientId "windows-login"
```

Quando a URL começa com `http://`, o instalador configura `RequireHttps=false` automaticamente. Use HTTP somente no laboratório/VM.

O instalador:

1. copia o bridge para `C:\Program Files\KeycloakWindowsBridge`;
2. instala `KeycloakWindowsBridge` como serviço `LocalSystem`;
3. copia a DLL para `C:\Program Files\KeycloakWindowsLogin`;
4. registra o COM CLSID `{9E2BB013-00FC-4ECD-8191-52614B2BEB01}`;
5. registra o Credential Provider no LogonUI;
6. mantém o Password Credential Provider original do Windows intacto.

## 5. Teste

Confira a instalação:

```powershell
.\scripts\status.ps1
```

Esperado:

```text
Status  Name
------  ----
Running KeycloakWindowsBridge

Provider registrado: True
COM registrado:      True
```

Depois:

```text
Win + L
```

ou encerre a sessão.

Na opção do Keycloak:

```text
Entrar com Keycloak

[Iniciar login]
```

Clique em **Iniciar login**. A tile mostrará algo semelhante a:

```text
Abra: http://.../realms/windows/device
Código: ABCD-EFGH
```

Abra a URL em outro navegador/dispositivo, informe o código e autentique usando o usuário criado no próprio Keycloak.

Volte ao Windows e clique:

```text
[Já autentiquei]
```

Quando aparecer:

```text
Autenticado. Clique em Entrar.
```

clique em **Entrar**.

O bridge cria uma conta parecida com:

```text
kc_10d923e3ad2347cc
```

A senha local é aleatória e não é a senha digitada no Keycloak.

## 6. Contas locais gerenciadas

Por padrão as contas `kc_*` são ocultadas da tela normal de usuários do Windows. Para deixá-las visíveis no laboratório:

```powershell
.\scripts\install.ps1 `
  -KeycloakBaseUrl "http://172.24.224.1:8080" `
  -Realm "windows" `
  -ShowManagedAccounts
```

A senha gerenciada **não é salva em LSA por padrão**, porque o fluxo não precisa dela depois que a autenticação terminou. Se quiser reproduzir o comportamento da primeira versão e persistir a senha como LSA Private Data:

```powershell
.\scripts\install.ps1 ... -PersistManagedPasswordInLsa
```

## 7. Desinstalação

```powershell
.\scripts\uninstall.ps1
```

Para também apagar todas as contas locais criadas pelo protótipo:

```powershell
.\scripts\uninstall.ps1 -RemoveManagedUsers
```

Se a DLL ainda estiver carregada pelo LogonUI, o registro será removido imediatamente, mas pode ser necessário reiniciar antes de o arquivo físico poder ser apagado.

## Design do Credential Provider

A tile usa `ICredentialProvider` + `ICredentialProviderCredential` como uma credencial genérica. Isso é intencional para o bootstrap: antes da autenticação do Keycloak ainda não existe um SID local para associar à tile. Depois que o Keycloak retorna `sub`, o bridge determina/cria a conta local e o provider envia a credencial final ao Windows.

O `GetSerialization()` produz `KERB_INTERACTIVE_UNLOCK_LOGON` e usa o authentication package `Negotiate`, seguindo o mesmo modelo de serialização usado pelos samples de Credential Provider da Microsoft.

## Segurança para laboratório

Teste primeiro em uma VM com snapshot.

**Não desabilite o login normal por senha do Windows durante o desenvolvimento.** Mantenha um administrador local conhecido para recuperação.

Para produção ainda seriam necessários, entre outros:

- assinatura de código da DLL e do serviço;
- política de enrollment/autorização de dispositivos;
- política de revogação e offboarding;
- tratamento explícito de offline logon;
- hardening do Keycloak/TLS;
- auditoria de criação e mudança de grupos locais;
- mecanismo de atualização/rollback do Credential Provider;
- revisão de threat model e pentest.
