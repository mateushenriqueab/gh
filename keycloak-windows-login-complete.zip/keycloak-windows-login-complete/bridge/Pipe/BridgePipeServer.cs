using System.IO.Pipes;
using System.Text;
using KeycloakWindowsBridge.Models;
using KeycloakWindowsBridge.Services;

namespace KeycloakWindowsBridge.Pipe;

public sealed class BridgePipeServer(
    KeycloakDeviceFlow keycloak,
    WindowsLocalAccountService accounts,
    LoginSessionStore sessions,
    ILogger<BridgePipeServer> logger)
{
    public const string PipeName = "KeycloakWindowsBridge";

    public async Task RunAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            var pipe = new NamedPipeServerStream(
                PipeName,
                PipeDirection.InOut,
                NamedPipeServerStream.MaxAllowedServerInstances,
                PipeTransmissionMode.Byte,
                PipeOptions.Asynchronous | PipeOptions.CurrentUserOnly);

            try
            {
                await pipe.WaitForConnectionAsync(ct);
                _ = Task.Run(() => HandleClientAsync(pipe, ct), CancellationToken.None);
            }
            catch
            {
                await pipe.DisposeAsync();
                if (ct.IsCancellationRequested) break;
                throw;
            }
        }
    }

    private async Task HandleClientAsync(NamedPipeServerStream pipe, CancellationToken serviceCt)
    {
        await using (pipe)
        using (var reader = new StreamReader(pipe, Encoding.UTF8, false, 1024, leaveOpen: true))
        using (var writer = new StreamWriter(pipe, new UTF8Encoding(false), 1024, leaveOpen: true) { AutoFlush = true })
        {
            try
            {
                var request = await reader.ReadLineAsync(serviceCt);
                if (string.IsNullOrWhiteSpace(request))
                {
                    await writer.WriteLineAsync("ERROR|empty request");
                    return;
                }

                var parts = request.Split('|');
                switch (parts[0].ToUpperInvariant())
                {
                    case "START":
                        await StartAsync(writer, serviceCt);
                        break;
                    case "STATUS" when parts.Length == 2:
                        await StatusAsync(parts[1], writer);
                        break;
                    default:
                        await writer.WriteLineAsync("ERROR|invalid command");
                        break;
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Named-pipe request failed.");
                try { await writer.WriteLineAsync("ERROR|" + Sanitize(ex.Message)); } catch { }
            }
        }
    }

    private async Task StartAsync(StreamWriter writer, CancellationToken ct)
    {
        var device = await keycloak.StartAsync(ct);
        var session = sessions.Add(device);

        _ = Task.Run(async () =>
        {
            try
            {
                var user = await keycloak.WaitForUserAsync(device, serviceCt);
                var local = accounts.EnsureLocalUser(user);
                session.LocalUser = local.Username;
                session.LocalPassword = local.Password;
                session.State = LoginState.Ready;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Keycloak login session {SessionId} failed.", session.Id);
                session.Error = Sanitize(ex.Message);
                session.State = LoginState.Failed;
            }
        }, CancellationToken.None);

        var complete = device.VerificationUriComplete ?? "";
        await writer.WriteLineAsync(
            $"STARTED|{session.Id}|{Sanitize(device.VerificationUri)}|{Sanitize(device.UserCode)}|{Sanitize(complete)}");
    }

    private async Task StatusAsync(string id, StreamWriter writer)
    {
        if (!sessions.TryGet(id, out var session) || session is null)
        {
            await writer.WriteLineAsync("ERROR|unknown session");
            return;
        }

        switch (session.State)
        {
            case LoginState.Pending:
                await writer.WriteLineAsync("PENDING");
                break;
            case LoginState.Failed:
                await writer.WriteLineAsync("ERROR|" + Sanitize(session.Error ?? "authentication failed"));
                break;
            case LoginState.Ready:
                await writer.WriteLineAsync($"READY|{session.LocalUser}|{session.LocalPassword}");
                break;
        }
    }

    private static string Sanitize(string value) =>
        value.Replace('|', '_').Replace('\r', ' ').Replace('\n', ' ');
}
