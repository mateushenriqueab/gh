using KeycloakWindowsBridge;
using KeycloakWindowsBridge.Pipe;
using KeycloakWindowsBridge.Services;

var builder = Host.CreateApplicationBuilder(new HostApplicationBuilderSettings
{
    Args = args,
    ContentRootPath = AppContext.BaseDirectory
});

builder.Services.AddWindowsService(options =>
{
    options.ServiceName = "KeycloakWindowsBridge";
});

builder.Services.Configure<KeycloakOptions>(builder.Configuration.GetSection("Keycloak"));
builder.Services.AddHttpClient<KeycloakDeviceFlow>();
builder.Services.AddSingleton<WindowsLocalAccountService>();
builder.Services.AddSingleton<LsaSecretStore>();
builder.Services.AddSingleton<LoginSessionStore>();
builder.Services.AddSingleton<BridgePipeServer>();
builder.Services.AddHostedService<Worker>();

await builder.Build().RunAsync();
