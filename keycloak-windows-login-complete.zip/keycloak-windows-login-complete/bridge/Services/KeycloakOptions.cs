namespace KeycloakWindowsBridge.Services;

public sealed class KeycloakOptions
{
    public string BaseUrl { get; set; } = "";
    public string Realm { get; set; } = "windows";
    public string ClientId { get; set; } = "windows-login";
    public string Scope { get; set; } = "openid profile email";
    public bool RequireHttps { get; set; } = true;
    public string AllowedEmailDomain { get; set; } = "";
    public bool HideManagedAccounts { get; set; } = true;
    public bool PersistManagedPasswordInLsa { get; set; } = false;

    public string RealmBase => $"{BaseUrl.TrimEnd('/')}/realms/{Uri.EscapeDataString(Realm)}";
    public string DeviceEndpoint => $"{RealmBase}/protocol/openid-connect/auth/device";
    public string TokenEndpoint => $"{RealmBase}/protocol/openid-connect/token";
    public string UserInfoEndpoint => $"{RealmBase}/protocol/openid-connect/userinfo";
}
