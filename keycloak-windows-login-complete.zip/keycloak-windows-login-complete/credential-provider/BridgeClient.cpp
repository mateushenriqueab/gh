#include "BridgeClient.h"
#include "Helpers.h"
#include <vector>

static std::vector<std::wstring> Split(const std::wstring& value, wchar_t separator)
{
    std::vector<std::wstring> output;
    size_t start = 0;
    for (;;)
    {
        const auto position = value.find(separator, start);
        output.emplace_back(value.substr(start,
            position == std::wstring::npos ? std::wstring::npos : position - start));
        if (position == std::wstring::npos) break;
        start = position + 1;
    }
    return output;
}

static HRESULT Utf8FromWide(const std::wstring& value, std::string& output)
{
    output.clear();
    if (value.empty()) return S_OK;

    const int bytes = WideCharToMultiByte(CP_UTF8, 0, value.data(),
        static_cast<int>(value.size()), nullptr, 0, nullptr, nullptr);
    if (bytes <= 0) return HRESULT_FROM_WIN32(GetLastError());

    output.resize(bytes);
    if (!WideCharToMultiByte(CP_UTF8, 0, value.data(),
        static_cast<int>(value.size()), output.data(), bytes, nullptr, nullptr))
        return HRESULT_FROM_WIN32(GetLastError());

    return S_OK;
}

static HRESULT WideFromUtf8(const std::string& value, std::wstring& output)
{
    output.clear();
    if (value.empty()) return S_OK;

    const int chars = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS,
        value.data(), static_cast<int>(value.size()), nullptr, 0);
    if (chars <= 0) return HRESULT_FROM_WIN32(GetLastError());

    output.resize(chars);
    if (!MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS,
        value.data(), static_cast<int>(value.size()), output.data(), chars))
        return HRESULT_FROM_WIN32(GetLastError());

    return S_OK;
}

HRESULT KeycloakBridgeClient::Request(const std::wstring& request, std::wstring& response)
{
    response.clear();

    constexpr PCWSTR pipeName = L"\\\\.\\pipe\\KeycloakWindowsBridge";
    if (!WaitNamedPipeW(pipeName, 5000))
        return HRESULT_FROM_WIN32(GetLastError());

    HANDLE pipe = CreateFileW(pipeName,
        GENERIC_READ | GENERIC_WRITE,
        0,
        nullptr,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        nullptr);

    if (pipe == INVALID_HANDLE_VALUE)
        return HRESULT_FROM_WIN32(GetLastError());

    std::string utf8;
    HRESULT hr = Utf8FromWide(request + L"\n", utf8);
    if (FAILED(hr))
    {
        CloseHandle(pipe);
        return hr;
    }

    DWORD written = 0;
    if (!WriteFile(pipe, utf8.data(), static_cast<DWORD>(utf8.size()), &written, nullptr))
    {
        const DWORD error = GetLastError();
        CloseHandle(pipe);
        return HRESULT_FROM_WIN32(error);
    }

    std::string buffer;
    char chunk[4096];
    for (;;)
    {
        DWORD read = 0;
        const BOOL ok = ReadFile(pipe, chunk, sizeof(chunk), &read, nullptr);
        if (!ok || read == 0) break;

        buffer.append(chunk, chunk + read);
        if (buffer.find('\n') != std::string::npos) break;

        if (buffer.size() > 64 * 1024)
        {
            CloseHandle(pipe);
            return HRESULT_FROM_WIN32(ERROR_BUFFER_OVERFLOW);
        }
    }
    CloseHandle(pipe);

    const auto newline = buffer.find('\n');
    if (newline != std::string::npos) buffer.resize(newline);
    if (!buffer.empty() && buffer.back() == '\r') buffer.pop_back();

    return WideFromUtf8(buffer, response);
}

HRESULT KeycloakBridgeClient::Start(KCStartResult& result)
{
    std::wstring response;
    HRESULT hr = Request(L"START", response);
    if (FAILED(hr)) return hr;

    const auto parts = Split(response, L'|');
    if (parts.size() < 5 || parts[0] != L"STARTED")
        return E_FAIL;

    result.sessionId = parts[1];
    result.verificationUri = parts[2];
    result.userCode = parts[3];
    result.verificationUriComplete = parts[4];
    return S_OK;
}

HRESULT KeycloakBridgeClient::Status(const std::wstring& sessionId, KCStatusResult& result)
{
    std::wstring response;
    HRESULT hr = Request(L"STATUS|" + sessionId, response);
    if (FAILED(hr)) return hr;

    auto parts = Split(response, L'|');
    if (parts.empty()) return E_FAIL;

    if (parts[0] == L"PENDING")
    {
        result.state = KCStatusResult::State::Pending;
    }
    else if (parts[0] == L"READY" && parts.size() >= 3)
    {
        result.state = KCStatusResult::State::Ready;
        result.username = parts[1];
        result.password = parts[2];
    }
    else
    {
        result.state = KCStatusResult::State::Error;
        result.error = parts.size() > 1 ? parts[1] : L"Erro desconhecido do bridge";
    }

    // Best-effort cleanup of temporary copies that may contain the managed password.
    SecureClearString(response);
    for (auto& part : parts) SecureClearString(part);
    return S_OK;
}
