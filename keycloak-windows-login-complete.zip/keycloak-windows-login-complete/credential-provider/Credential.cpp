#include "Credential.h"
#include "Dll.h"
#include "Guid.h"
#include "Helpers.h"
#include <new>
#include <sstream>

KeycloakCredential::KeycloakCredential()
{
    DllAddRef();
    _fieldStrings[FI_TITLE] = L"Entrar com Keycloak";
    _fieldStrings[FI_STATUS] = L"Clique em \"Iniciar login\" para gerar o código.";
    _fieldStrings[FI_START] = L"Iniciar login";
    _fieldStrings[FI_CHECK] = L"Já autentiquei";
    _fieldStrings[FI_SUBMIT] = L"Entrar";
}

KeycloakCredential::~KeycloakCredential()
{
    UnAdvise();
    ResetSensitiveState();
    DllRelease();
}

HRESULT KeycloakCredential::Initialize(CREDENTIAL_PROVIDER_USAGE_SCENARIO usageScenario)
{
    if (usageScenario != CPUS_LOGON && usageScenario != CPUS_UNLOCK_WORKSTATION)
        return E_NOTIMPL;

    _usageScenario = usageScenario;
    return S_OK;
}

HRESULT KeycloakCredential::QueryInterface(REFIID riid, void** ppv)
{
    if (!ppv) return E_POINTER;
    *ppv = nullptr;

    if (riid == IID_IUnknown || riid == IID_ICredentialProviderCredential)
    {
        *ppv = static_cast<ICredentialProviderCredential*>(this);
        AddRef();
        return S_OK;
    }
    return E_NOINTERFACE;
}

ULONG KeycloakCredential::AddRef()
{
    return static_cast<ULONG>(InterlockedIncrement(&_refCount));
}

ULONG KeycloakCredential::Release()
{
    const long count = InterlockedDecrement(&_refCount);
    if (count == 0) delete this;
    return static_cast<ULONG>(count);
}

HRESULT KeycloakCredential::Advise(ICredentialProviderCredentialEvents* events)
{
    if (_events) _events->Release();
    _events = events;
    if (_events) _events->AddRef();
    return S_OK;
}

HRESULT KeycloakCredential::UnAdvise()
{
    if (_events)
    {
        _events->Release();
        _events = nullptr;
    }
    return S_OK;
}

HRESULT KeycloakCredential::SetSelected(BOOL* autoLogon)
{
    if (!autoLogon) return E_POINTER;
    *autoLogon = FALSE;
    return S_OK;
}

HRESULT KeycloakCredential::SetDeselected()
{
    return S_OK;
}

HRESULT KeycloakCredential::GetFieldState(
    DWORD fieldId,
    CREDENTIAL_PROVIDER_FIELD_STATE* state,
    CREDENTIAL_PROVIDER_FIELD_INTERACTIVE_STATE* interactiveState)
{
    if (!state || !interactiveState) return E_POINTER;
    if (fieldId >= FI_NUM_FIELDS) return E_INVALIDARG;

    *state = g_fieldStates[fieldId].state;
    *interactiveState = g_fieldStates[fieldId].interactiveState;
    return S_OK;
}

HRESULT KeycloakCredential::GetStringValue(DWORD fieldId, PWSTR* value)
{
    if (fieldId >= FI_NUM_FIELDS) return E_INVALIDARG;
    return DuplicateString(_fieldStrings[fieldId].c_str(), value);
}

HRESULT KeycloakCredential::GetBitmapValue(DWORD, HBITMAP* bitmap)
{
    if (bitmap) *bitmap = nullptr;
    return E_NOTIMPL;
}

HRESULT KeycloakCredential::GetCheckboxValue(DWORD, BOOL* checked, PWSTR* label)
{
    if (checked) *checked = FALSE;
    if (label) *label = nullptr;
    return E_NOTIMPL;
}

HRESULT KeycloakCredential::GetComboBoxValueCount(DWORD, DWORD* count, DWORD* selectedItem)
{
    if (count) *count = 0;
    if (selectedItem) *selectedItem = 0;
    return E_NOTIMPL;
}

HRESULT KeycloakCredential::GetComboBoxValueAt(DWORD, DWORD, PWSTR* value)
{
    if (value) *value = nullptr;
    return E_NOTIMPL;
}

HRESULT KeycloakCredential::GetSubmitButtonValue(DWORD fieldId, DWORD* adjacentTo)
{
    if (!adjacentTo) return E_POINTER;
    if (fieldId != FI_SUBMIT) return E_INVALIDARG;
    *adjacentTo = FI_STATUS;
    return S_OK;
}

HRESULT KeycloakCredential::SetStringValue(DWORD, PCWSTR)
{
    return E_NOTIMPL;
}

HRESULT KeycloakCredential::SetCheckboxValue(DWORD, BOOL)
{
    return E_NOTIMPL;
}

HRESULT KeycloakCredential::SetComboBoxSelectedValue(DWORD, DWORD)
{
    return E_NOTIMPL;
}

void KeycloakCredential::SetStatus(const std::wstring& text)
{
    _fieldStrings[FI_STATUS] = text;
    if (_events)
        _events->SetFieldString(this, FI_STATUS, _fieldStrings[FI_STATUS].c_str());
}

void KeycloakCredential::ResetSensitiveState()
{
    SecureClearString(_localPassword);
    _localUsername.clear();
    _sessionId.clear();
    _ready = false;
}

HRESULT KeycloakCredential::StartKeycloakLogin()
{
    ResetSensitiveState();

    KCStartResult result;
    const HRESULT hr = _bridge.Start(result);
    if (FAILED(hr))
    {
        std::wstringstream message;
        message << L"Não foi possível falar com o bridge. HRESULT=0x"
                << std::hex << static_cast<unsigned long>(hr);
        SetStatus(message.str());
        return S_OK;
    }

    _sessionId = result.sessionId;

    std::wstring message = L"Abra: " + result.verificationUri +
        L"\r\nCódigo: " + result.userCode;
    if (!result.verificationUriComplete.empty())
        message += L"\r\nLink direto: " + result.verificationUriComplete;

    SetStatus(message);
    return S_OK;
}

HRESULT KeycloakCredential::RefreshKeycloakStatus()
{
    if (_sessionId.empty())
    {
        SetStatus(L"Clique primeiro em \"Iniciar login\".");
        return S_OK;
    }

    KCStatusResult status;
    const HRESULT hr = _bridge.Status(_sessionId, status);
    if (FAILED(hr))
    {
        std::wstringstream message;
        message << L"Erro consultando o bridge. HRESULT=0x"
                << std::hex << static_cast<unsigned long>(hr);
        SetStatus(message.str());
        return S_OK;
    }

    switch (status.state)
    {
    case KCStatusResult::State::Pending:
        SetStatus(L"Aguardando autenticação no Keycloak...");
        break;

    case KCStatusResult::State::Error:
        SetStatus(L"Keycloak: " + status.error);
        break;

    case KCStatusResult::State::Ready:
        _localUsername = status.username;
        _localPassword = status.password;
        _ready = true;
        SetStatus(L"Autenticado. Clique em Entrar.");
        break;
    }

    SecureClearString(status.password);
    return S_OK;
}

HRESULT KeycloakCredential::CommandLinkClicked(DWORD fieldId)
{
    switch (fieldId)
    {
    case FI_START:
        return StartKeycloakLogin();
    case FI_CHECK:
        return RefreshKeycloakStatus();
    default:
        return E_INVALIDARG;
    }
}

HRESULT KeycloakCredential::GetSerialization(
    CREDENTIAL_PROVIDER_GET_SERIALIZATION_RESPONSE* response,
    CREDENTIAL_PROVIDER_CREDENTIAL_SERIALIZATION* serialization,
    PWSTR* optionalStatusText,
    CREDENTIAL_PROVIDER_STATUS_ICON* optionalStatusIcon)
{
    if (!response || !serialization || !optionalStatusText || !optionalStatusIcon)
        return E_POINTER;

    *response = CPGSR_NO_CREDENTIAL_NOT_FINISHED;
    ZeroMemory(serialization, sizeof(*serialization));
    *optionalStatusText = nullptr;
    *optionalStatusIcon = CPSI_NONE;

    if (!_ready)
    {
        RefreshKeycloakStatus();
        if (!_ready)
        {
            DuplicateString(_fieldStrings[FI_STATUS].c_str(), optionalStatusText);
            *optionalStatusIcon = CPSI_WARNING;
            return S_OK;
        }
    }

    wchar_t machineName[MAX_COMPUTERNAME_LENGTH + 1]{};
    DWORD chars = ARRAYSIZE(machineName);
    if (!GetComputerNameW(machineName, &chars))
        return HRESULT_FROM_WIN32(GetLastError());

    BYTE* packed = nullptr;
    DWORD packedSize = 0;
    ULONG authPackage = 0;
    HRESULT hr = PackLocalCredential(
        machineName,
        _localUsername.c_str(),
        _localPassword.c_str(),
        _usageScenario,
        &packed,
        &packedSize,
        &authPackage);

    if (FAILED(hr))
    {
        DuplicateString(L"Falha ao montar a credencial local do Windows.", optionalStatusText);
        *optionalStatusIcon = CPSI_ERROR;
        return hr;
    }

    serialization->ulAuthenticationPackage = authPackage;
    serialization->clsidCredentialProvider = CLSID_KeycloakCredentialProvider;
    serialization->cbSerialization = packedSize;
    serialization->rgbSerialization = packed;
    *response = CPGSR_RETURN_CREDENTIAL_FINISHED;
    return S_OK;
}

HRESULT KeycloakCredential::ReportResult(
    NTSTATUS status,
    NTSTATUS,
    PWSTR* optionalStatusText,
    CREDENTIAL_PROVIDER_STATUS_ICON* optionalStatusIcon)
{
    if (!optionalStatusText || !optionalStatusIcon) return E_POINTER;
    *optionalStatusText = nullptr;
    *optionalStatusIcon = CPSI_NONE;

    if (status == 0)
    {
        ResetSensitiveState();
        return S_OK;
    }

    ResetSensitiveState();
    SetStatus(L"O Windows recusou a credencial local. Inicie um novo login no Keycloak.");
    DuplicateString(_fieldStrings[FI_STATUS].c_str(), optionalStatusText);
    *optionalStatusIcon = CPSI_ERROR;
    return S_OK;
}
