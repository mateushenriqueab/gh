#pragma once
#include <windows.h>
#include <credentialprovider.h>
#include <string>
#include "BridgeClient.h"
#include "Fields.h"

class KeycloakCredential final : public ICredentialProviderCredential
{
public:
    KeycloakCredential();
    HRESULT Initialize(CREDENTIAL_PROVIDER_USAGE_SCENARIO usageScenario);

    // IUnknown
    IFACEMETHODIMP QueryInterface(REFIID riid, void** ppv) override;
    IFACEMETHODIMP_(ULONG) AddRef() override;
    IFACEMETHODIMP_(ULONG) Release() override;

    // ICredentialProviderCredential
    IFACEMETHODIMP Advise(ICredentialProviderCredentialEvents* events) override;
    IFACEMETHODIMP UnAdvise() override;
    IFACEMETHODIMP SetSelected(BOOL* autoLogon) override;
    IFACEMETHODIMP SetDeselected() override;
    IFACEMETHODIMP GetFieldState(DWORD fieldId,
        CREDENTIAL_PROVIDER_FIELD_STATE* state,
        CREDENTIAL_PROVIDER_FIELD_INTERACTIVE_STATE* interactiveState) override;
    IFACEMETHODIMP GetStringValue(DWORD fieldId, PWSTR* value) override;
    IFACEMETHODIMP GetBitmapValue(DWORD fieldId, HBITMAP* bitmap) override;
    IFACEMETHODIMP GetCheckboxValue(DWORD fieldId, BOOL* checked, PWSTR* label) override;
    IFACEMETHODIMP GetComboBoxValueCount(DWORD fieldId, DWORD* count, DWORD* selectedItem) override;
    IFACEMETHODIMP GetComboBoxValueAt(DWORD fieldId, DWORD item, PWSTR* value) override;
    IFACEMETHODIMP GetSubmitButtonValue(DWORD fieldId, DWORD* adjacentTo) override;
    IFACEMETHODIMP SetStringValue(DWORD fieldId, PCWSTR value) override;
    IFACEMETHODIMP SetCheckboxValue(DWORD fieldId, BOOL checked) override;
    IFACEMETHODIMP SetComboBoxSelectedValue(DWORD fieldId, DWORD selectedItem) override;
    IFACEMETHODIMP CommandLinkClicked(DWORD fieldId) override;
    IFACEMETHODIMP GetSerialization(
        CREDENTIAL_PROVIDER_GET_SERIALIZATION_RESPONSE* response,
        CREDENTIAL_PROVIDER_CREDENTIAL_SERIALIZATION* serialization,
        PWSTR* optionalStatusText,
        CREDENTIAL_PROVIDER_STATUS_ICON* optionalStatusIcon) override;
    IFACEMETHODIMP ReportResult(
        NTSTATUS status,
        NTSTATUS substatus,
        PWSTR* optionalStatusText,
        CREDENTIAL_PROVIDER_STATUS_ICON* optionalStatusIcon) override;

private:
    ~KeycloakCredential();

    void SetStatus(const std::wstring& text);
    HRESULT StartKeycloakLogin();
    HRESULT RefreshKeycloakStatus();
    void ResetSensitiveState();

    long _refCount = 1;
    CREDENTIAL_PROVIDER_USAGE_SCENARIO _usageScenario = CPUS_INVALID;
    ICredentialProviderCredentialEvents* _events = nullptr;
    std::wstring _fieldStrings[FI_NUM_FIELDS];

    KeycloakBridgeClient _bridge;
    std::wstring _sessionId;
    std::wstring _localUsername;
    std::wstring _localPassword;
    bool _ready = false;
};
