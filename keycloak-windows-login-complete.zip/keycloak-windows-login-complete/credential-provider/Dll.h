#pragma once
#include <windows.h>

extern HINSTANCE g_hInstance;
void DllAddRef();
void DllRelease();
