#include <windows.h>
#include <credentialprovider.h>
#include "Fields.h"

static wchar_t kTitleLabel[] = L"Keycloak";
static wchar_t kStatusLabel[] = L"Status";
static wchar_t kStartLabel[] = L"Iniciar login";
static wchar_t kCheckLabel[] = L"Já autentiquei";
static wchar_t kSubmitLabel[] = L"Entrar";

CREDENTIAL_PROVIDER_FIELD_DESCRIPTOR g_fieldDescriptors[FI_NUM_FIELDS] =
{
    { FI_TITLE,  CPFT_LARGE_TEXT,    kTitleLabel,  CPFG_CREDENTIAL_PROVIDER_LABEL },
    { FI_STATUS, CPFT_SMALL_TEXT,    kStatusLabel, GUID_NULL },
    { FI_START,  CPFT_COMMAND_LINK,  kStartLabel,  GUID_NULL },
    { FI_CHECK,  CPFT_COMMAND_LINK,  kCheckLabel,  GUID_NULL },
    { FI_SUBMIT, CPFT_SUBMIT_BUTTON, kSubmitLabel, GUID_NULL },
};

const FIELD_STATE_PAIR g_fieldStates[FI_NUM_FIELDS] =
{
    { CPFS_DISPLAY_IN_BOTH,          CPFIS_NONE },
    { CPFS_DISPLAY_IN_SELECTED_TILE, CPFIS_NONE },
    { CPFS_DISPLAY_IN_SELECTED_TILE, CPFIS_NONE },
    { CPFS_DISPLAY_IN_SELECTED_TILE, CPFIS_NONE },
    { CPFS_DISPLAY_IN_SELECTED_TILE, CPFIS_NONE },
};
