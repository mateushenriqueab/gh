#pragma once
#include <credentialprovider.h>

struct FIELD_STATE_PAIR
{
    CREDENTIAL_PROVIDER_FIELD_STATE state;
    CREDENTIAL_PROVIDER_FIELD_INTERACTIVE_STATE interactiveState;
};

enum FIELD_ID : DWORD
{
    FI_TITLE = 0,
    FI_STATUS,
    FI_START,
    FI_CHECK,
    FI_SUBMIT,
    FI_NUM_FIELDS
};

extern CREDENTIAL_PROVIDER_FIELD_DESCRIPTOR g_fieldDescriptors[FI_NUM_FIELDS];
extern const FIELD_STATE_PAIR g_fieldStates[FI_NUM_FIELDS];
