#pragma once
#include <guiddef.h>

// {9E2BB013-00FC-4ECD-8191-52614B2BEB01}
extern const CLSID CLSID_KeycloakCredentialProvider;
