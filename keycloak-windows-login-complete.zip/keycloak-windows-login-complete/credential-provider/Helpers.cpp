#include "Helpers.h"
#include <ntsecapi.h>
#include <wincred.h>
#include <security.h>
#include <intsafe.h>
#include <cstring>

HRESULT DuplicateString(PCWSTR source, PWSTR* destination)
{
    if (!destination) return E_POINTER;
    *destination = nullptr;
    if (!source) return E_INVALIDARG;

    const size_t chars = wcslen(source) + 1;
    size_t bytes = 0;
    HRESULT hr = SizeTMult(chars, sizeof(wchar_t), &bytes);
    if (FAILED(hr)) return hr;

    auto buffer = static_cast<PWSTR>(CoTaskMemAlloc(bytes));
    if (!buffer) return E_OUTOFMEMORY;

    memcpy_s(buffer, bytes, source, bytes);
    *destination = buffer;
    return S_OK;
}

HRESULT CopyFieldDescriptor(
    const CREDENTIAL_PROVIDER_FIELD_DESCRIPTOR& source,
    CREDENTIAL_PROVIDER_FIELD_DESCRIPTOR** destination)
{
    if (!destination) return E_POINTER;
    *destination = nullptr;

    auto copy = static_cast<CREDENTIAL_PROVIDER_FIELD_DESCRIPTOR*>(
        CoTaskMemAlloc(sizeof(CREDENTIAL_PROVIDER_FIELD_DESCRIPTOR)));
    if (!copy) return E_OUTOFMEMORY;

    copy->dwFieldID = source.dwFieldID;
    copy->cpft = source.cpft;
    copy->guidFieldType = source.guidFieldType;
    copy->pszLabel = nullptr;

    HRESULT hr = S_OK;
    if (source.pszLabel)
        hr = DuplicateString(source.pszLabel, &copy->pszLabel);

    if (FAILED(hr))
    {
        CoTaskMemFree(copy);
        return hr;
    }

    *destination = copy;
    return S_OK;
}

void SecureClearString(std::wstring& value)
{
    if (!value.empty())
        SecureZeroMemory(value.data(), value.size() * sizeof(wchar_t));
    value.clear();
    value.shrink_to_fit();
}

static HRESULT InitUnicodeString(PCWSTR value, UNICODE_STRING* output)
{
    if (!value || !output) return E_INVALIDARG;

    const size_t chars = wcslen(value);
    USHORT byteLength = 0;
    HRESULT hr = SizeTToUShort(chars * sizeof(wchar_t), &byteLength);
    if (FAILED(hr)) return hr;

    output->Length = byteLength;
    output->MaximumLength = byteLength;
    output->Buffer = const_cast<PWSTR>(value);
    return S_OK;
}

static HRESULT ProtectPassword(PCWSTR password, PWSTR* protectedPassword)
{
    if (!protectedPassword) return E_POINTER;
    *protectedPassword = nullptr;
    if (!password) return E_INVALIDARG;

    CRED_PROTECTION_TYPE protectionType = CredUnprotected;
    if (CredIsProtectedW(const_cast<PWSTR>(password), &protectionType) &&
        protectionType != CredUnprotected)
    {
        return DuplicateString(password, protectedPassword);
    }

    const DWORD inputChars = static_cast<DWORD>(wcslen(password) + 1);
    DWORD requiredChars = 0;
    CRED_PROTECTION_TYPE ignored = CredUnprotected;

    if (!CredProtectW(FALSE,
                      const_cast<PWSTR>(password),
                      inputChars,
                      nullptr,
                      &requiredChars,
                      &ignored))
    {
        const DWORD error = GetLastError();
        if (error != ERROR_INSUFFICIENT_BUFFER)
            return HRESULT_FROM_WIN32(error);
    }

    auto buffer = static_cast<PWSTR>(
        CoTaskMemAlloc(static_cast<size_t>(requiredChars) * sizeof(wchar_t)));
    if (!buffer) return E_OUTOFMEMORY;

    if (!CredProtectW(FALSE,
                      const_cast<PWSTR>(password),
                      inputChars,
                      buffer,
                      &requiredChars,
                      &ignored))
    {
        const DWORD error = GetLastError();
        SecureZeroMemory(buffer, static_cast<size_t>(requiredChars) * sizeof(wchar_t));
        CoTaskMemFree(buffer);
        return HRESULT_FROM_WIN32(error);
    }

    *protectedPassword = buffer;
    return S_OK;
}

static void CopyPackedUnicodeString(
    const UNICODE_STRING& source,
    BYTE*& next,
    BYTE* base,
    UNICODE_STRING* destination)
{
    destination->Length = source.Length;
    destination->MaximumLength = source.Length;

    if (source.Length == 0)
    {
        destination->Buffer = nullptr;
        return;
    }

    memcpy(next, source.Buffer, source.Length);
    const ULONG_PTR offset = static_cast<ULONG_PTR>(next - base);
    destination->Buffer = reinterpret_cast<PWSTR>(offset);
    next += source.Length;
}

static HRESULT RetrieveNegotiatePackage(ULONG* package)
{
    if (!package) return E_POINTER;

    HANDLE lsa = nullptr;
    NTSTATUS status = LsaConnectUntrusted(&lsa);
    if (status != 0)
        return HRESULT_FROM_WIN32(LsaNtStatusToWinError(status));

    char negotiateName[] = "Negotiate";
    LSA_STRING name{};
    name.Buffer = negotiateName;
    name.Length = static_cast<USHORT>(strlen(negotiateName));
    name.MaximumLength = name.Length + 1;

    status = LsaLookupAuthenticationPackage(lsa, &name, package);
    LsaDeregisterLogonProcess(lsa);

    if (status != 0)
        return HRESULT_FROM_WIN32(LsaNtStatusToWinError(status));

    return S_OK;
}

HRESULT PackLocalCredential(
    PCWSTR domain,
    PCWSTR username,
    PCWSTR password,
    CREDENTIAL_PROVIDER_USAGE_SCENARIO usageScenario,
    BYTE** serialization,
    DWORD* serializationSize,
    ULONG* authenticationPackage)
{
    if (!domain || !username || !password ||
        !serialization || !serializationSize || !authenticationPackage)
        return E_INVALIDARG;

    *serialization = nullptr;
    *serializationSize = 0;
    *authenticationPackage = 0;

    PWSTR protectedPassword = nullptr;
    HRESULT hr = ProtectPassword(password, &protectedPassword);
    if (FAILED(hr)) return hr;

    KERB_INTERACTIVE_UNLOCK_LOGON input{};
    switch (usageScenario)
    {
    case CPUS_LOGON:
        input.Logon.MessageType = KerbInteractiveLogon;
        break;
    case CPUS_UNLOCK_WORKSTATION:
        input.Logon.MessageType = KerbWorkstationUnlockLogon;
        break;
    default:
        SecureZeroMemory(protectedPassword, wcslen(protectedPassword) * sizeof(wchar_t));
        CoTaskMemFree(protectedPassword);
        return E_NOTIMPL;
    }

    hr = InitUnicodeString(domain, &input.Logon.LogonDomainName);
    if (SUCCEEDED(hr)) hr = InitUnicodeString(username, &input.Logon.UserName);
    if (SUCCEEDED(hr)) hr = InitUnicodeString(protectedPassword, &input.Logon.Password);

    if (SUCCEEDED(hr))
    {
        const size_t totalSize = sizeof(KERB_INTERACTIVE_UNLOCK_LOGON) +
            input.Logon.LogonDomainName.Length +
            input.Logon.UserName.Length +
            input.Logon.Password.Length;

        if (totalSize > MAXDWORD)
        {
            hr = HRESULT_FROM_WIN32(ERROR_ARITHMETIC_OVERFLOW);
        }
        else
        {
            auto output = static_cast<KERB_INTERACTIVE_UNLOCK_LOGON*>(
                CoTaskMemAlloc(totalSize));

            if (!output)
            {
                hr = E_OUTOFMEMORY;
            }
            else
            {
                ZeroMemory(output, totalSize);
                output->Logon.MessageType = input.Logon.MessageType;
                output->LogonId = input.LogonId;

                BYTE* base = reinterpret_cast<BYTE*>(output);
                BYTE* next = base + sizeof(KERB_INTERACTIVE_UNLOCK_LOGON);

                CopyPackedUnicodeString(input.Logon.LogonDomainName, next, base, &output->Logon.LogonDomainName);
                CopyPackedUnicodeString(input.Logon.UserName, next, base, &output->Logon.UserName);
                CopyPackedUnicodeString(input.Logon.Password, next, base, &output->Logon.Password);

                ULONG package = 0;
                hr = RetrieveNegotiatePackage(&package);
                if (SUCCEEDED(hr))
                {
                    *serialization = base;
                    *serializationSize = static_cast<DWORD>(totalSize);
                    *authenticationPackage = package;
                }
                else
                {
                    SecureZeroMemory(output, totalSize);
                    CoTaskMemFree(output);
                }
            }
        }
    }

    if (protectedPassword)
    {
        SecureZeroMemory(protectedPassword, wcslen(protectedPassword) * sizeof(wchar_t));
        CoTaskMemFree(protectedPassword);
    }

    return hr;
}
