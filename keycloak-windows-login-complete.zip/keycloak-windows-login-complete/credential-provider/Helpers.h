#pragma once
#include <windows.h>
#include <credentialprovider.h>
#include <string>

HRESULT CopyFieldDescriptor(
    const CREDENTIAL_PROVIDER_FIELD_DESCRIPTOR& source,
    CREDENTIAL_PROVIDER_FIELD_DESCRIPTOR** destination);

HRESULT DuplicateString(PCWSTR source, PWSTR* destination);

HRESULT PackLocalCredential(
    PCWSTR domain,
    PCWSTR username,
    PCWSTR password,
    CREDENTIAL_PROVIDER_USAGE_SCENARIO usageScenario,
    BYTE** serialization,
    DWORD* serializationSize,
    ULONG* authenticationPackage);

void SecureClearString(std::wstring& value);
