#include "Provider.h"
#include "Dll.h"
#include "Fields.h"
#include "Helpers.h"
#include <new>

KeycloakProvider::KeycloakProvider()
{
    DllAddRef();
}

KeycloakProvider::~KeycloakProvider()
{
    if (_credential)
    {
        _credential->Release();
        _credential = nullptr;
    }
    DllRelease();
}

HRESULT KeycloakProvider::QueryInterface(REFIID riid, void** ppv)
{
    if (!ppv) return E_POINTER;
    *ppv = nullptr;

    if (riid == IID_IUnknown || riid == IID_ICredentialProvider)
    {
        *ppv = static_cast<ICredentialProvider*>(this);
        AddRef();
        return S_OK;
    }
    return E_NOINTERFACE;
}

ULONG KeycloakProvider::AddRef()
{
    return static_cast<ULONG>(InterlockedIncrement(&_refCount));
}

ULONG KeycloakProvider::Release()
{
    const long count = InterlockedDecrement(&_refCount);
    if (count == 0) delete this;
    return static_cast<ULONG>(count);
}

HRESULT KeycloakProvider::SetUsageScenario(
    CREDENTIAL_PROVIDER_USAGE_SCENARIO usageScenario,
    DWORD)
{
    if (usageScenario != CPUS_LOGON && usageScenario != CPUS_UNLOCK_WORKSTATION)
        return E_NOTIMPL;

    _usageScenario = usageScenario;

    if (_credential)
    {
        _credential->Release();
        _credential = nullptr;
    }

    return S_OK;
}

HRESULT KeycloakProvider::SetSerialization(const CREDENTIAL_PROVIDER_CREDENTIAL_SERIALIZATION*)
{
    return E_NOTIMPL;
}

HRESULT KeycloakProvider::Advise(ICredentialProviderEvents*, UINT_PTR)
{
    return S_OK;
}

HRESULT KeycloakProvider::UnAdvise()
{
    return S_OK;
}

HRESULT KeycloakProvider::GetFieldDescriptorCount(DWORD* count)
{
    if (!count) return E_POINTER;
    *count = FI_NUM_FIELDS;
    return S_OK;
}

HRESULT KeycloakProvider::GetFieldDescriptorAt(
    DWORD index,
    CREDENTIAL_PROVIDER_FIELD_DESCRIPTOR** descriptor)
{
    if (index >= FI_NUM_FIELDS) return E_INVALIDARG;
    return CopyFieldDescriptor(g_fieldDescriptors[index], descriptor);
}

HRESULT KeycloakProvider::EnsureCredential()
{
    if (_credential) return S_OK;
    if (_usageScenario == CPUS_INVALID) return E_UNEXPECTED;

    auto credential = new (std::nothrow) KeycloakCredential();
    if (!credential) return E_OUTOFMEMORY;

    HRESULT hr = credential->Initialize(_usageScenario);
    if (FAILED(hr))
    {
        credential->Release();
        return hr;
    }

    _credential = credential;
    return S_OK;
}

HRESULT KeycloakProvider::GetCredentialCount(
    DWORD* count,
    DWORD* defaultCredential,
    BOOL* autoLogonWithDefault)
{
    if (!count || !defaultCredential || !autoLogonWithDefault) return E_POINTER;

    HRESULT hr = EnsureCredential();
    if (FAILED(hr))
    {
        *count = 0;
        *defaultCredential = CREDENTIAL_PROVIDER_NO_DEFAULT;
        *autoLogonWithDefault = FALSE;
        return hr;
    }

    *count = 1;
    *defaultCredential = CREDENTIAL_PROVIDER_NO_DEFAULT;
    *autoLogonWithDefault = FALSE;
    return S_OK;
}

HRESULT KeycloakProvider::GetCredentialAt(
    DWORD index,
    ICredentialProviderCredential** credential)
{
    if (!credential) return E_POINTER;
    *credential = nullptr;
    if (index != 0) return E_INVALIDARG;

    HRESULT hr = EnsureCredential();
    if (FAILED(hr)) return hr;

    return _credential->QueryInterface(IID_PPV_ARGS(credential));
}

HRESULT CreateKeycloakProvider(REFIID riid, void** ppv)
{
    if (!ppv) return E_POINTER;
    *ppv = nullptr;

    auto provider = new (std::nothrow) KeycloakProvider();
    if (!provider) return E_OUTOFMEMORY;

    const HRESULT hr = provider->QueryInterface(riid, ppv);
    provider->Release();
    return hr;
}
