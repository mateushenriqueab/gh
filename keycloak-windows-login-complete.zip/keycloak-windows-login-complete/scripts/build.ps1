#requires -Version 5.1
[CmdletBinding()]
param(
    [ValidateSet('Debug','Release')]
    [string]$Configuration = 'Release'
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$artifacts = Join-Path $root 'artifacts'
$bridgeOut = Join-Path $artifacts 'bridge'
$providerOut = Join-Path $artifacts 'provider'

if (-not [Environment]::Is64BitOperatingSystem) {
    throw 'Este projeto foi preparado para Windows x64.'
}

$dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
if (-not $dotnet) {
    throw 'dotnet SDK 8 não encontrado. Instale o .NET 8 SDK.'
}

$vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
$msbuild = $null
if (Test-Path $vswhere) {
    $msbuild = & $vswhere -latest -products * `
        -requires Microsoft.Component.MSBuild Microsoft.VisualStudio.Component.VC.Tools.x86.x64 `
        -find 'MSBuild\**\Bin\MSBuild.exe' | Select-Object -First 1
}
if (-not $msbuild) {
    $cmd = Get-Command msbuild.exe -ErrorAction SilentlyContinue
    if ($cmd) { $msbuild = $cmd.Source }
}
if (-not $msbuild) {
    throw 'MSBuild/C++ Build Tools não encontrados. Instale Visual Studio 2022 Build Tools com Desktop development with C++ e Windows SDK.'
}

Remove-Item $artifacts -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path $bridgeOut, $providerOut | Out-Null

Write-Host '==> Publicando bridge .NET 8 (win-x64, self-contained)...' -ForegroundColor Cyan
& dotnet publish (Join-Path $root 'bridge\KeycloakWindowsBridge.csproj') `
    -c $Configuration `
    -r win-x64 `
    --self-contained true `
    -o $bridgeOut
if ($LASTEXITCODE -ne 0) { throw 'Falha no build do bridge.' }

Write-Host '==> Compilando Credential Provider C++ x64...' -ForegroundColor Cyan
& $msbuild (Join-Path $root 'credential-provider\KeycloakCredentialProvider.sln') `
    /m `
    /t:Build `
    "/p:Configuration=$Configuration" `
    /p:Platform=x64
if ($LASTEXITCODE -ne 0) { throw 'Falha no build do Credential Provider.' }

$providerDll = Join-Path $root "credential-provider\bin\x64\$Configuration\KeycloakCredentialProvider.dll"
if (-not (Test-Path $providerDll)) {
    throw "DLL não encontrada após o build: $providerDll"
}
Copy-Item $providerDll (Join-Path $providerOut 'KeycloakCredentialProvider.dll') -Force

Write-Host ''
Write-Host 'BUILD OK' -ForegroundColor Green
Write-Host "Bridge:   $bridgeOut"
Write-Host "Provider: $providerOut\KeycloakCredentialProvider.dll"
Write-Host 'Próximo passo: execute .\scripts\install.ps1 como Administrador.'
