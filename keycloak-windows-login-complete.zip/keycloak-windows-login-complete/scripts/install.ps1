#requires -Version 5.1
#requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$KeycloakBaseUrl,
    [string]$Realm,
    [string]$ClientId,
    [string]$AllowedEmailDomain,
    [switch]$ShowManagedAccounts,
    [switch]$PersistManagedPasswordInLsa
)

$ErrorActionPreference = 'Stop'
if (-not [Environment]::Is64BitProcess) {
    throw 'Execute este script no PowerShell x64.'
}

$root = Split-Path -Parent $PSScriptRoot
$bridgeSource = Join-Path $root 'artifacts\bridge'
$providerSource = Join-Path $root 'artifacts\provider\KeycloakCredentialProvider.dll'

if (-not (Test-Path (Join-Path $bridgeSource 'KeycloakWindowsBridge.exe'))) {
    throw 'Bridge não buildado. Rode primeiro: .\scripts\build.ps1'
}
if (-not (Test-Path $providerSource)) {
    throw 'Credential Provider não buildado. Rode primeiro: .\scripts\build.ps1'
}

$serviceName = 'KeycloakWindowsBridge'
$bridgeTarget = Join-Path $env:ProgramFiles 'KeycloakWindowsBridge'
$providerTarget = Join-Path $env:ProgramFiles 'KeycloakWindowsLogin'
$providerDll = Join-Path $providerTarget 'KeycloakCredentialProvider.dll'
$clsid = '{9E2BB013-00FC-4ECD-8191-52614B2BEB01}'
$providerReg = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\Credential Providers\$clsid"
$comReg = "HKLM:\SOFTWARE\Classes\CLSID\$clsid\InprocServer32"

Write-Host '==> Removendo registro antigo do provider, se existir...' -ForegroundColor Cyan
Remove-Item $providerReg -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item (Split-Path -Parent $comReg) -Recurse -Force -ErrorAction SilentlyContinue

$existing = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
if ($existing) {
    Write-Host '==> Parando serviço antigo...' -ForegroundColor Cyan
    Stop-Service $serviceName -Force -ErrorAction SilentlyContinue
    & sc.exe delete $serviceName | Out-Null
    for ($i = 0; $i -lt 20; $i++) {
        Start-Sleep -Milliseconds 250
        if (-not (Get-Service -Name $serviceName -ErrorAction SilentlyContinue)) { break }
    }
}

Write-Host '==> Instalando bridge...' -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path $bridgeTarget | Out-Null
Copy-Item (Join-Path $bridgeSource '*') $bridgeTarget -Recurse -Force

$configPath = Join-Path $bridgeTarget 'appsettings.json'
$config = Get-Content $configPath -Raw | ConvertFrom-Json

if ($KeycloakBaseUrl) {
    $config.Keycloak.BaseUrl = $KeycloakBaseUrl.TrimEnd('/')
    $config.Keycloak.RequireHttps = -not $config.Keycloak.BaseUrl.StartsWith('http://', [StringComparison]::OrdinalIgnoreCase)
}
if ($Realm) { $config.Keycloak.Realm = $Realm }
if ($ClientId) { $config.Keycloak.ClientId = $ClientId }
if ($PSBoundParameters.ContainsKey('AllowedEmailDomain')) {
    $config.Keycloak.AllowedEmailDomain = $AllowedEmailDomain
}
$config.Keycloak.HideManagedAccounts = -not $ShowManagedAccounts.IsPresent
$config.Keycloak.PersistManagedPasswordInLsa = $PersistManagedPasswordInLsa.IsPresent
$config | ConvertTo-Json -Depth 10 | Set-Content $configPath -Encoding UTF8

$bridgeExe = Join-Path $bridgeTarget 'KeycloakWindowsBridge.exe'
New-Service -Name $serviceName `
    -BinaryPathName ('"' + $bridgeExe + '"') `
    -DisplayName 'Keycloak Windows Bridge' `
    -Description 'Keycloak OIDC Device Authorization bridge for Windows Credential Provider' `
    -StartupType Automatic | Out-Null
Start-Service $serviceName

Write-Host '==> Instalando Credential Provider...' -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path $providerTarget | Out-Null
try {
    Copy-Item $providerSource $providerDll -Force
}
catch {
    throw "Não consegui substituir $providerDll. Se uma versão antiga estiver carregada pelo LogonUI, reinicie a VM após desinstalar e rode novamente. $($_.Exception.Message)"
}

New-Item -Path $comReg -Force | Out-Null
Set-Item -Path $comReg -Value $providerDll
New-ItemProperty -Path $comReg -Name 'ThreadingModel' -Value 'Apartment' -PropertyType String -Force | Out-Null

New-Item -Path $providerReg -Force | Out-Null
Set-Item -Path $providerReg -Value 'Keycloak Windows Login'

Write-Host ''
Write-Host 'INSTALAÇÃO OK' -ForegroundColor Green
Write-Host "Serviço: $serviceName"
Write-Host "Provider CLSID: $clsid"
Write-Host "Config: $configPath"
Write-Host ''
Write-Host 'Agora use Win+L ou encerre a sessão. Se o provider não aparecer na primeira tentativa, reinicie a VM.' -ForegroundColor Yellow
Write-Host 'NÃO desabilite o Password Credential Provider do Windows durante os testes.' -ForegroundColor Yellow
