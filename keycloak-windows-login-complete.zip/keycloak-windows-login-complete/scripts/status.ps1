#requires -Version 5.1
$serviceName = 'KeycloakWindowsBridge'
$clsid = '{9E2BB013-00FC-4ECD-8191-52614B2BEB01}'
$providerReg = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\Credential Providers\$clsid"
$comReg = "HKLM:\SOFTWARE\Classes\CLSID\$clsid\InprocServer32"

Write-Host '=== Keycloak Windows Login ==='
Get-Service $serviceName -ErrorAction SilentlyContinue | Format-Table Status, Name, DisplayName -AutoSize
Write-Host "Provider registrado: $(Test-Path $providerReg)"
Write-Host "COM registrado:      $(Test-Path $comReg)"
if (Test-Path $comReg) {
    Write-Host "DLL: $((Get-Item $comReg).GetValue(''))"
}
