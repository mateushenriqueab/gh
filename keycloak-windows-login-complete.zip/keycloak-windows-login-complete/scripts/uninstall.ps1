#requires -Version 5.1
#requires -RunAsAdministrator
[CmdletBinding()]
param(
    [switch]$RemoveManagedUsers
)

$ErrorActionPreference = 'Stop'
$serviceName = 'KeycloakWindowsBridge'
$clsid = '{9E2BB013-00FC-4ECD-8191-52614B2BEB01}'
$providerReg = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\Credential Providers\$clsid"
$comClsidReg = "HKLM:\SOFTWARE\Classes\CLSID\$clsid"
$bridgeTarget = Join-Path $env:ProgramFiles 'KeycloakWindowsBridge'
$providerTarget = Join-Path $env:ProgramFiles 'KeycloakWindowsLogin'

Write-Host '==> Desregistrando Credential Provider...' -ForegroundColor Cyan
Remove-Item $providerReg -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item $comClsidReg -Recurse -Force -ErrorAction SilentlyContinue

Write-Host '==> Removendo serviço...' -ForegroundColor Cyan
Stop-Service $serviceName -Force -ErrorAction SilentlyContinue
if (Get-Service $serviceName -ErrorAction SilentlyContinue) {
    & sc.exe delete $serviceName | Out-Null
}

if ($RemoveManagedUsers) {
    Write-Host '==> Removendo usuários locais kc_*...' -ForegroundColor Cyan
    Get-LocalUser -ErrorAction SilentlyContinue |
        Where-Object Name -Like 'kc_*' |
        ForEach-Object {
            Remove-LocalUser -Name $_.Name
            Remove-ItemProperty `
                -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\SpecialAccounts\UserList' `
                -Name $_.Name -ErrorAction SilentlyContinue
        }
}

Start-Sleep -Milliseconds 500
foreach ($path in @($bridgeTarget, $providerTarget)) {
    try { Remove-Item $path -Recurse -Force -ErrorAction Stop }
    catch { Write-Warning "Não foi possível apagar $path agora (DLL possivelmente carregada). Reinicie a VM e apague depois." }
}

Write-Host 'DESINSTALADO. O provider deixa de ser enumerado após uma nova sessão do LogonUI.' -ForegroundColor Green
