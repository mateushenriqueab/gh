# Keycloak + Windows local logon bridge

This starter kit implements the architecture:

```
Windows LogonUI
  -> custom Credential Provider (C++)
  -> \\.\pipe\KeycloakWindowsBridge
  -> .NET 8 Windows Service (LocalSystem)
  -> Keycloak OIDC Device Authorization Grant
  -> optional Microsoft Entra ID broker inside Keycloak
  -> local Windows user `kc_<hash(sub)>`
  -> random local password stored in LSA private data
  -> serialized back to LogonUI as a normal local Windows credential
```

It does **not** make Keycloak an LSA authentication package. Windows still performs the
final local SAM authentication; Keycloak is the online identity proof used to provision and
rotate the managed local credential.

## 1. Keycloak client

Create an OIDC client:

- Client ID: `windows-login`
- Client authentication: OFF (public client)
- Standard flow: optional/off for this flow
- Direct access grants: OFF
- OAuth 2.0 Device Authorization Grant: ON
- scopes: `openid profile email`
- keep normal/full access tokens for this client; do not enable lightweight access tokens if you use the included UserInfo lookup

If Microsoft Entra ID is configured as an Identity Provider in Keycloak, the user can choose
Microsoft on the Keycloak login page. No AD/LDAP is required on the Windows machine.

## 2. Configure bridge

Edit `bridge/appsettings.json`:

```json
{
  "Keycloak": {
    "BaseUrl": "https://sso.example.com",
    "Realm": "corp",
    "ClientId": "windows-login",
    "Scope": "openid profile email",
    "RequireHttps": true,
    "AllowedEmailDomain": "example.com"
  }
}
```

Leave `AllowedEmailDomain` empty to accept any successfully authenticated Keycloak user.

## 3. Publish/install bridge

Run from an elevated PowerShell:

```powershell
dotnet publish .\bridge\KeycloakWindowsBridge.csproj -c Release
.\scripts\install-bridge.ps1
```

The service should run as `LocalSystem`.

## 4. Credential Provider

Start from Microsoft's V2 Credential Provider sample and add:

- `credential-provider/BridgeClient.h`
- `credential-provider/BridgeClient.cpp`
- the integration described in `credential-provider/INTEGRATION.md`
- the local credential serialization in `GetSerialization.snippet.cpp`

The official sample already contains the helper functions that build
`KERB_INTERACTIVE_UNLOCK_LOGON`, pack it, and retrieve the Negotiate authentication package.

## 5. Login flow

1. User clicks `Entrar com Keycloak` on LogonUI.
2. Credential Provider calls `START` through the named pipe.
3. The tile displays Keycloak's verification URL and user code.
4. User authenticates in Keycloak (or via the Entra broker).
5. Credential Provider calls `STATUS|<sessionId>`.
6. Bridge creates/updates a local `kc_<hash>` account and rotates a random local password.
7. Bridge returns the local username/password only through the SYSTEM-only named pipe.
8. Credential Provider serializes the local credential and Windows performs the logon.

## Security notes

- Test in a VM first.
- Keep the built-in Windows password provider enabled during development.
- Keep a separate local administrator account as recovery.
- Use HTTPS to Keycloak in production.
- Do not log access tokens, device codes, or the generated local password.
- Rotate the local password after each successful online authentication (already done here).
- For production, add device enrollment, revocation policy, offline-logon policy, certificate pinning/mTLS if desired, and code-sign the Credential Provider DLL/service.
