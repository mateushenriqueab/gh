namespace KeycloakWindowsBridge.Models;

public enum LoginState
{
    Pending,
    Ready,
    Failed
}

public sealed class LoginSession
{
    public required string Id { get; init; }
    public required DateTimeOffset ExpiresAt { get; init; }
    public required DeviceAuthorizationResponse Device { get; init; }
    public LoginState State { get; set; } = LoginState.Pending;
    public string? LocalUser { get; set; }
    public string? LocalPassword { get; set; }
    public string? Error { get; set; }
}
