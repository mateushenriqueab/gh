using System.Text.Json.Serialization;

namespace KeycloakWindowsBridge.Models;

public sealed class UserInfo
{
    [JsonPropertyName("sub")]
    public string Subject { get; set; } = "";

    [JsonPropertyName("preferred_username")]
    public string PreferredUsername { get; set; } = "";

    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("email")]
    public string? Email { get; set; }

    [JsonPropertyName("email_verified")]
    public bool EmailVerified { get; set; }
}
