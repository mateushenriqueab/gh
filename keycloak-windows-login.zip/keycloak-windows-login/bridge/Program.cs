using KeycloakWindowsBridge;
using KeycloakWindowsBridge.Pipe;
using KeycloakWindowsBridge.Services;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.AddWindowsService(options =>
{
    options.ServiceName = "Keycloak Windows Bridge";
});

builder.Services.Configure<KeycloakOptions>(builder.Configuration.GetSection("Keycloak"));
builder.Services.AddHttpClient<KeycloakDeviceFlow>();
builder.Services.AddSingleton<WindowsLocalAccountService>();
builder.Services.AddSingleton<LsaSecretStore>();
builder.Services.AddSingleton<LoginSessionStore>();
builder.Services.AddSingleton<BridgePipeServer>();
builder.Services.AddHostedService<Worker>();

await builder.Build().RunAsync();
