using System.Net.Http.Headers;
using System.Text.Json;
using KeycloakWindowsBridge.Models;
using Microsoft.Extensions.Options;

namespace KeycloakWindowsBridge.Services;

public sealed class KeycloakDeviceFlow
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);
    private readonly HttpClient _http;
    private readonly KeycloakOptions _options;
    private readonly ILogger<KeycloakDeviceFlow> _logger;

    public KeycloakDeviceFlow(HttpClient http, IOptions<KeycloakOptions> options, ILogger<KeycloakDeviceFlow> logger)
    {
        _http = http;
        _options = options.Value;
        _logger = logger;

        if (!Uri.TryCreate(_options.BaseUrl, UriKind.Absolute, out var uri))
            throw new InvalidOperationException("Keycloak BaseUrl is invalid.");

        if (_options.RequireHttps && uri.Scheme != Uri.UriSchemeHttps)
            throw new InvalidOperationException("Keycloak BaseUrl must use HTTPS.");
    }

    public async Task<DeviceAuthorizationResponse> StartAsync(CancellationToken ct)
    {
        using var content = new FormUrlEncodedContent(new Dictionary<string, string>
        {
            ["client_id"] = _options.ClientId,
            ["scope"] = _options.Scope
        });

        using var response = await _http.PostAsync(_options.DeviceEndpoint, content, ct);
        var body = await response.Content.ReadAsStringAsync(ct);
        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException($"Device authorization failed ({(int)response.StatusCode}): {body}");

        return JsonSerializer.Deserialize<DeviceAuthorizationResponse>(body, Json)
               ?? throw new InvalidOperationException("Invalid device authorization response.");
    }

    public async Task<UserInfo> WaitForUserAsync(DeviceAuthorizationResponse device, CancellationToken ct)
    {
        var delaySeconds = Math.Max(device.Interval, 2);
        var deadline = DateTimeOffset.UtcNow.AddSeconds(device.ExpiresIn);

        while (DateTimeOffset.UtcNow < deadline)
        {
            ct.ThrowIfCancellationRequested();
            await Task.Delay(TimeSpan.FromSeconds(delaySeconds), ct);

            using var content = new FormUrlEncodedContent(new Dictionary<string, string>
            {
                ["grant_type"] = "urn:ietf:params:oauth:grant-type:device_code",
                ["device_code"] = device.DeviceCode,
                ["client_id"] = _options.ClientId
            });

            using var response = await _http.PostAsync(_options.TokenEndpoint, content, ct);
            var body = await response.Content.ReadAsStringAsync(ct);

            if (response.IsSuccessStatusCode)
            {
                var token = JsonSerializer.Deserialize<TokenResponse>(body, Json)
                            ?? throw new InvalidOperationException("Invalid token response.");

                if (string.IsNullOrWhiteSpace(token.AccessToken))
                    throw new InvalidOperationException("Keycloak returned no access_token.");

                return await GetUserInfoAsync(token.AccessToken, ct);
            }

            using var doc = JsonDocument.Parse(body);
            var error = doc.RootElement.TryGetProperty("error", out var e) ? e.GetString() : null;

            switch (error)
            {
                case "authorization_pending":
                    continue;
                case "slow_down":
                    delaySeconds += 5;
                    continue;
                case "access_denied":
                    throw new UnauthorizedAccessException("The Keycloak login was denied.");
                case "expired_token":
                    throw new TimeoutException("The Keycloak device code expired.");
                default:
                    throw new InvalidOperationException($"Token polling failed: {body}");
            }
        }

        throw new TimeoutException("The Keycloak login expired.");
    }

    private async Task<UserInfo> GetUserInfoAsync(string accessToken, CancellationToken ct)
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, _options.UserInfoEndpoint);
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

        using var response = await _http.SendAsync(request, ct);
        var body = await response.Content.ReadAsStringAsync(ct);
        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException($"UserInfo failed ({(int)response.StatusCode}): {body}");

        var user = JsonSerializer.Deserialize<UserInfo>(body, Json)
                   ?? throw new InvalidOperationException("Invalid UserInfo response.");

        if (string.IsNullOrWhiteSpace(user.Subject))
            throw new InvalidOperationException("Keycloak UserInfo did not contain sub.");

        if (!string.IsNullOrWhiteSpace(_options.AllowedEmailDomain))
        {
            if (string.IsNullOrWhiteSpace(user.Email) ||
                !user.Email.EndsWith("@" + _options.AllowedEmailDomain, StringComparison.OrdinalIgnoreCase))
            {
                throw new UnauthorizedAccessException("User is outside the allowed email domain.");
            }
        }

        _logger.LogInformation("Keycloak authentication completed for subject {Subject}.", user.Subject);
        return user;
    }
}
