using System.Collections.Concurrent;
using KeycloakWindowsBridge.Models;

namespace KeycloakWindowsBridge.Services;

public sealed class LoginSessionStore
{
    private readonly ConcurrentDictionary<string, LoginSession> _sessions = new();

    public LoginSession Add(DeviceAuthorizationResponse device)
    {
        Cleanup();
        var session = new LoginSession
        {
            Id = Guid.NewGuid().ToString("N"),
            Device = device,
            ExpiresAt = DateTimeOffset.UtcNow.AddSeconds(device.ExpiresIn + 120)
        };
        _sessions[session.Id] = session;
        return session;
    }

    public bool TryGet(string id, out LoginSession? session)
    {
        Cleanup();
        return _sessions.TryGetValue(id, out session);
    }

    private void Cleanup()
    {
        var now = DateTimeOffset.UtcNow;
        foreach (var pair in _sessions)
        {
            if (pair.Value.ExpiresAt <= now)
                _sessions.TryRemove(pair.Key, out _);
        }
    }
}
