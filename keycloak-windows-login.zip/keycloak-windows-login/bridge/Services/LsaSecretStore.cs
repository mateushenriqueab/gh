using System.ComponentModel;
using System.Runtime.InteropServices;

namespace KeycloakWindowsBridge.Services;

public sealed class LsaSecretStore
{
    private const uint POLICY_GET_PRIVATE_INFORMATION = 0x00000004;
    private const uint POLICY_CREATE_SECRET = 0x00000020;

    public void Store(string key, string value)
    {
        var attrs = new LSA_OBJECT_ATTRIBUTES
        {
            Length = (uint)Marshal.SizeOf<LSA_OBJECT_ATTRIBUTES>()
        };

        var status = LsaOpenPolicy(IntPtr.Zero, ref attrs,
            POLICY_CREATE_SECRET | POLICY_GET_PRIVATE_INFORMATION, out var policyHandle);
        ThrowIfLsaError(status);

        try
        {
            using var keyString = LsaUnicodeString.FromString(key);
            using var valueString = LsaUnicodeString.FromString(value);
            status = LsaStorePrivateData(policyHandle, ref keyString.Value, ref valueString.Value);
            ThrowIfLsaError(status);
        }
        finally
        {
            LsaClose(policyHandle);
        }
    }

    private static void ThrowIfLsaError(uint status)
    {
        if (status == 0) return;
        var winError = LsaNtStatusToWinError(status);
        throw new Win32Exception((int)winError);
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct LSA_OBJECT_ATTRIBUTES
    {
        public uint Length;
        public IntPtr RootDirectory;
        public IntPtr ObjectName;
        public uint Attributes;
        public IntPtr SecurityDescriptor;
        public IntPtr SecurityQualityOfService;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct LSA_UNICODE_STRING
    {
        public ushort Length;
        public ushort MaximumLength;
        public IntPtr Buffer;
    }

    private sealed class LsaUnicodeString : IDisposable
    {
        public LSA_UNICODE_STRING Value;

        private LsaUnicodeString(string value)
        {
            Value.Buffer = Marshal.StringToHGlobalUni(value);
            Value.Length = checked((ushort)(value.Length * 2));
            Value.MaximumLength = checked((ushort)((value.Length + 1) * 2));
        }

        public static LsaUnicodeString FromString(string value) => new(value);

        public void Dispose()
        {
            if (Value.Buffer != IntPtr.Zero)
            {
                Marshal.ZeroFreeGlobalAllocUnicode(Value.Buffer);
                Value.Buffer = IntPtr.Zero;
            }
        }
    }

    [DllImport("advapi32.dll")]
    private static extern uint LsaOpenPolicy(IntPtr systemName, ref LSA_OBJECT_ATTRIBUTES objectAttributes,
        uint desiredAccess, out IntPtr policyHandle);

    [DllImport("advapi32.dll")]
    private static extern uint LsaStorePrivateData(IntPtr policyHandle, ref LSA_UNICODE_STRING keyName,
        ref LSA_UNICODE_STRING privateData);

    [DllImport("advapi32.dll")]
    private static extern uint LsaClose(IntPtr objectHandle);

    [DllImport("advapi32.dll")]
    private static extern uint LsaNtStatusToWinError(uint status);
}
