using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using KeycloakWindowsBridge.Models;

namespace KeycloakWindowsBridge.Services;

public sealed class WindowsLocalAccountService(LsaSecretStore lsa, ILogger<WindowsLocalAccountService> logger)
{
    private const uint USER_PRIV_USER = 1;
    private const uint UF_SCRIPT = 0x0001;
    private const uint UF_DONT_EXPIRE_PASSWD = 0x10000;
    private const uint NERR_Success = 0;
    private const uint NERR_UserExists = 2224;
    private const uint ERROR_MEMBER_IN_ALIAS = 1378;

    public LocalCredential EnsureLocalUser(UserInfo user)
    {
        var username = BuildLocalUsername(user.Subject);
        var password = GeneratePassword();

        var info = new USER_INFO_1
        {
            usri1_name = username,
            usri1_password = password,
            usri1_priv = USER_PRIV_USER,
            usri1_comment = $"Keycloak managed account ({user.Email ?? user.PreferredUsername})",
            usri1_flags = UF_SCRIPT | UF_DONT_EXPIRE_PASSWD
        };

        var result = NetUserAdd(null, 1, ref info, out _);
        if (result == NERR_UserExists)
        {
            var passwordInfo = new USER_INFO_1003 { usri1003_password = password };
            result = NetUserSetInfo(null, username, 1003, ref passwordInfo, out _);
        }

        if (result != NERR_Success)
            throw new Win32Exception((int)result, $"Could not create/update local user {username}. NetAPI={result}");

        AddToBuiltinUsers(username);
        lsa.Store($"L$KeycloakWindows.{username}", password);

        logger.LogInformation("Local Windows account {Username} is ready.", username);
        return new LocalCredential(username, password);
    }

    private static void AddToBuiltinUsers(string username)
    {
        var sid = new SecurityIdentifier(WellKnownSidType.BuiltinUsersSid, null);
        var account = (NTAccount)sid.Translate(typeof(NTAccount));
        var groupName = account.Value.Contains('\\')
            ? account.Value[(account.Value.IndexOf('\\') + 1)..]
            : account.Value;

        var member = new LOCALGROUP_MEMBERS_INFO_3 { lgrmi3_domainandname = username };
        var result = NetLocalGroupAddMembers(null, groupName, 3, ref member, 1);
        if (result != NERR_Success && result != ERROR_MEMBER_IN_ALIAS)
            throw new Win32Exception((int)result, $"Could not add {username} to {groupName}. NetAPI={result}");
    }

    private static string BuildLocalUsername(string subject)
    {
        var hash = SHA256.HashData(Encoding.UTF8.GetBytes(subject));
        return "kc_" + Convert.ToHexString(hash)[..16].ToLowerInvariant();
    }

    private static string GeneratePassword()
    {
        var bytes = RandomNumberGenerator.GetBytes(32);
        return Convert.ToBase64String(bytes)
            .Replace('+', '-')
            .Replace('/', '_')
            .TrimEnd('=') + "!9aZ";
    }

    public sealed record LocalCredential(string Username, string Password);

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct USER_INFO_1
    {
        [MarshalAs(UnmanagedType.LPWStr)] public string usri1_name;
        [MarshalAs(UnmanagedType.LPWStr)] public string usri1_password;
        public uint usri1_password_age;
        public uint usri1_priv;
        [MarshalAs(UnmanagedType.LPWStr)] public string? usri1_home_dir;
        [MarshalAs(UnmanagedType.LPWStr)] public string? usri1_comment;
        public uint usri1_flags;
        [MarshalAs(UnmanagedType.LPWStr)] public string? usri1_script_path;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct USER_INFO_1003
    {
        [MarshalAs(UnmanagedType.LPWStr)] public string usri1003_password;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct LOCALGROUP_MEMBERS_INFO_3
    {
        [MarshalAs(UnmanagedType.LPWStr)] public string lgrmi3_domainandname;
    }

    [DllImport("Netapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern uint NetUserAdd(string? servername, uint level, ref USER_INFO_1 buf, out uint parm_err);

    [DllImport("Netapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern uint NetUserSetInfo(string? servername, string username, uint level, ref USER_INFO_1003 buf, out uint parm_err);

    [DllImport("Netapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern uint NetLocalGroupAddMembers(string? servername, string groupname, uint level, ref LOCALGROUP_MEMBERS_INFO_3 buf, uint totalentries);
}
