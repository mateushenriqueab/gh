using KeycloakWindowsBridge.Pipe;

namespace KeycloakWindowsBridge;

public sealed class Worker(BridgePipeServer server, ILogger<Worker> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        logger.LogInformation("Keycloak Windows Bridge started.");
        await server.RunAsync(stoppingToken);
    }
}
