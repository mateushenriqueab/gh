#include "BridgeClient.h"
#include <vector>

static std::vector<std::wstring> Split(const std::wstring& value, wchar_t sep)
{
    std::vector<std::wstring> out;
    size_t start = 0;
    while (true)
    {
        auto pos = value.find(sep, start);
        out.emplace_back(value.substr(start, pos == std::wstring::npos ? pos : pos - start));
        if (pos == std::wstring::npos) break;
        start = pos + 1;
    }
    return out;
}

HRESULT KeycloakBridgeClient::Request(const std::wstring& request, std::wstring& response)
{
    HANDLE h = CreateFileW(
        L"\\\\.\\pipe\\KeycloakWindowsBridge",
        GENERIC_READ | GENERIC_WRITE,
        0, nullptr, OPEN_EXISTING, 0, nullptr);

    if (h == INVALID_HANDLE_VALUE)
        return HRESULT_FROM_WIN32(GetLastError());

    std::wstring line = request + L"\n";
    std::string utf8;
    int bytes = WideCharToMultiByte(CP_UTF8, 0, line.c_str(), (int)line.size(), nullptr, 0, nullptr, nullptr);
    utf8.resize(bytes);
    WideCharToMultiByte(CP_UTF8, 0, line.c_str(), (int)line.size(), utf8.data(), bytes, nullptr, nullptr);

    DWORD written = 0;
    if (!WriteFile(h, utf8.data(), (DWORD)utf8.size(), &written, nullptr))
    {
        auto err = GetLastError();
        CloseHandle(h);
        return HRESULT_FROM_WIN32(err);
    }

    std::string buffer;
    char chunk[2048];
    DWORD read = 0;
    while (ReadFile(h, chunk, sizeof(chunk), &read, nullptr) && read > 0)
    {
        buffer.append(chunk, chunk + read);
        if (buffer.find('\n') != std::string::npos) break;
    }
    CloseHandle(h);

    auto lf = buffer.find('\n');
    if (lf != std::string::npos) buffer.resize(lf);
    if (!buffer.empty() && buffer.back() == '\r') buffer.pop_back();

    int chars = MultiByteToWideChar(CP_UTF8, 0, buffer.data(), (int)buffer.size(), nullptr, 0);
    response.resize(chars);
    MultiByteToWideChar(CP_UTF8, 0, buffer.data(), (int)buffer.size(), response.data(), chars);
    return S_OK;
}

HRESULT KeycloakBridgeClient::Start(KCStartResult& result)
{
    std::wstring response;
    HRESULT hr = Request(L"START", response);
    if (FAILED(hr)) return hr;

    auto p = Split(response, L'|');
    if (p.size() < 5 || p[0] != L"STARTED") return E_FAIL;

    result.sessionId = p[1];
    result.verificationUri = p[2];
    result.userCode = p[3];
    result.verificationUriComplete = p[4];
    return S_OK;
}

HRESULT KeycloakBridgeClient::Status(const std::wstring& sessionId, KCStatusResult& result)
{
    std::wstring response;
    HRESULT hr = Request(L"STATUS|" + sessionId, response);
    if (FAILED(hr)) return hr;

    auto p = Split(response, L'|');
    if (p.empty()) return E_FAIL;

    if (p[0] == L"PENDING")
    {
        result.state = KCStatusResult::State::Pending;
        return S_OK;
    }

    if (p[0] == L"READY" && p.size() >= 3)
    {
        result.state = KCStatusResult::State::Ready;
        result.username = p[1];
        result.password = p[2];
        return S_OK;
    }

    result.state = KCStatusResult::State::Error;
    result.error = p.size() > 1 ? p[1] : L"Unknown bridge error";
    return S_OK;
}
