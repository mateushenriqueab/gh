#pragma once
#include <windows.h>
#include <string>

struct KCStartResult
{
    std::wstring sessionId;
    std::wstring verificationUri;
    std::wstring userCode;
    std::wstring verificationUriComplete;
};

struct KCStatusResult
{
    enum class State { Pending, Ready, Error } state = State::Error;
    std::wstring username;
    std::wstring password;
    std::wstring error;
};

class KeycloakBridgeClient
{
public:
    HRESULT Start(KCStartResult& result);
    HRESULT Status(const std::wstring& sessionId, KCStatusResult& result);

private:
    HRESULT Request(const std::wstring& request, std::wstring& response);
};
