// Drop-in idea for CSampleCredential::GetSerialization after the Keycloak
// flow has returned _kcUsername / _kcPassword. This uses the helper functions
// already included in Microsoft's SampleV2CredentialProvider.

HRESULT CSampleCredential::SerializeKeycloakLocalCredential(
    const std::wstring& username,
    const std::wstring& password,
    CREDENTIAL_PROVIDER_GET_SERIALIZATION_RESPONSE* pcpgsr,
    CREDENTIAL_PROVIDER_CREDENTIAL_SERIALIZATION* pcpcs)
{
    PWSTR protectedPassword = nullptr;
    HRESULT hr = ProtectIfNecessaryAndCopyPassword(password.c_str(), _cpus, &protectedPassword);
    if (FAILED(hr)) return hr;

    wchar_t machineName[MAX_COMPUTERNAME_LENGTH + 1]{};
    DWORD cch = ARRAYSIZE(machineName);
    if (!GetComputerNameW(machineName, &cch))
    {
        CoTaskMemFree(protectedPassword);
        return HRESULT_FROM_WIN32(GetLastError());
    }

    KERB_INTERACTIVE_UNLOCK_LOGON kiul{};
    hr = KerbInteractiveUnlockLogonInit(
        machineName,
        username.c_str(),
        protectedPassword,
        _cpus,
        &kiul);

    if (SUCCEEDED(hr))
        hr = KerbInteractiveUnlockLogonPack(kiul, &pcpcs->rgbSerialization, &pcpcs->cbSerialization);

    if (SUCCEEDED(hr))
    {
        ULONG authPackage = 0;
        hr = RetrieveNegotiateAuthPackage(&authPackage);
        if (SUCCEEDED(hr))
        {
            pcpcs->ulAuthenticationPackage = authPackage;
            pcpcs->clsidCredentialProvider = CLSID_CSample; // replace with your CLSID
            *pcpgsr = CPGSR_RETURN_CREDENTIAL_FINISHED;
        }
    }

    CoTaskMemFree(protectedPassword);
    return hr;
}
