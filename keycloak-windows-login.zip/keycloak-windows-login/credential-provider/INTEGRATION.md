# Credential Provider integration

Use Microsoft's `Samples/CredentialProvider/cpp` (SampleV2CredentialProvider) as the base.
Do not replace Windows' password provider while testing.

## Tile fields

A minimal Keycloak tile can contain:

- large text: `Entrar com Keycloak`
- small text/status field
- command link: `Iniciar login`
- command link/button: `Já autentiquei`

The device flow is intentionally external: LogonUI runs on the secure desktop, so the
user authenticates at the Keycloak verification URL from another browser/device.
If Keycloak brokers to Microsoft Entra ID, choosing Microsoft there completes the same flow.

## Add members to CSampleCredential

```cpp
#include "BridgeClient.h"
#include <string>

KeycloakBridgeClient _kcBridge;
std::wstring _kcSessionId;
std::wstring _kcUsername;
std::wstring _kcPassword;
bool _kcReady = false;
```

## Start button

From `CommandLinkClicked` (or your chosen field):

```cpp
KCStartResult start;
HRESULT hr = _kcBridge.Start(start);
if (SUCCEEDED(hr))
{
    _kcSessionId = start.sessionId;

    std::wstring text = L"Abra: " + start.verificationUri +
                        L"   Código: " + start.userCode;

    _pCredProvCredentialEvents->SetFieldString(
        this,
        SFI_LOGONSTATUS_TEXT,
        text.c_str());
}
```

## Check authentication button

```cpp
KCStatusResult status;
HRESULT hr = _kcBridge.Status(_kcSessionId, status);
if (FAILED(hr))
    return hr;

if (status.state == KCStatusResult::State::Pending)
{
    _pCredProvCredentialEvents->SetFieldString(
        this, SFI_LOGONSTATUS_TEXT, L"Aguardando autenticação...");
    return S_OK;
}

if (status.state == KCStatusResult::State::Error)
{
    _pCredProvCredentialEvents->SetFieldString(
        this, SFI_LOGONSTATUS_TEXT, status.error.c_str());
    return S_OK;
}

_kcUsername = status.username;
_kcPassword = status.password;
_kcReady = true;

_pCredProvCredentialEvents->SetFieldString(
    this, SFI_LOGONSTATUS_TEXT, L"Autenticado. Clique em entrar.");
```

## GetSerialization

If `_kcReady == true`, call the implementation from `GetSerialization.snippet.cpp`.
The local account is created by the bridge before READY is returned.

```cpp
if (_kcReady)
{
    return SerializeKeycloakLocalCredential(
        _kcUsername,
        _kcPassword,
        pcpgsr,
        pcpcs);
}
```

After a successful logon, clear `_kcPassword` from memory as soon as possible.

## Important

The bridge service must run as LocalSystem because it creates the local SAM account and
writes the local secret. The named pipe uses `CurrentUserOnly`, so the Credential Provider
must also be running under the system logon context (the normal LogonUI case).

For the first test, keep at least one known working local administrator account and keep the
Microsoft password credential provider enabled so you cannot lock yourself out of the VM.
