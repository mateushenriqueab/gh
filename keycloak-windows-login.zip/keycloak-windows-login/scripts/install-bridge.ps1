param(
    [string]$PublishDir = "$PSScriptRoot\..\bridge\bin\Release\net8.0-windows\win-x64\publish"
)

$ErrorActionPreference = "Stop"
$target = "$env:ProgramFiles\KeycloakWindowsBridge"

if (-not (Test-Path "$PublishDir\KeycloakWindowsBridge.exe")) {
    throw "Publish the bridge first: dotnet publish .\bridge\KeycloakWindowsBridge.csproj -c Release"
}

New-Item -ItemType Directory -Force -Path $target | Out-Null
Copy-Item "$PublishDir\*" $target -Recurse -Force

if (Get-Service KeycloakWindowsBridge -ErrorAction SilentlyContinue) {
    Stop-Service KeycloakWindowsBridge -Force -ErrorAction SilentlyContinue
    sc.exe delete KeycloakWindowsBridge | Out-Null
    Start-Sleep -Seconds 1
}

sc.exe create KeycloakWindowsBridge `
    binPath= "`"$target\KeycloakWindowsBridge.exe`"" `
    start= auto `
    obj= LocalSystem | Out-Null

sc.exe description KeycloakWindowsBridge "Keycloak authentication bridge for Windows Credential Provider" | Out-Null
Start-Service KeycloakWindowsBridge
Get-Service KeycloakWindowsBridge
