$ErrorActionPreference = "Stop"
Stop-Service KeycloakWindowsBridge -Force -ErrorAction SilentlyContinue
sc.exe delete KeycloakWindowsBridge
